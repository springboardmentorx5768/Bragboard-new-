# My Learning Journey: Building BragBoard (5 Weeks)

## Project Overview
I have built **BragBoard**, a full-stack recognition platform. This project allows users to share achievements, tag colleagues, and interact through a modern, responsive interface.

## What I Learned Each Week
*   **Weeks 1-2: Foundations & Security**
    *   Set up a **FastAPI** backend and a **React** frontend.
    *   Implemented secure user authentication using **JWT tokens** and **Argon2** password hashing.
*   **Week 3: Core Features & Database Logic**
    *   Built the "Shout-out" posting system.
    *   Mastered **Many-to-Many relationships** to allow tagging multiple recipients in one post.
*   **Week 4: UI/UX & Styling**
    *   Designed a premium, responsive interface using **Tailwind CSS**.
    *   Developed reusable components like `PostCard` and `Navbar` for a clean, modular structure.
*   **Week 5: Advanced Interactions**
    *   Added a **Multi-Reaction System** (Like, Clap, Star) with fast, "optimistic" UI updates.
    *   Implemented image uploads and advanced feed filtering by department and date.

## Technologies I Mastered
*   **Frontend**: React.js, Tailwind CSS, JavaScript (ES6+), Fetch API.
*   **Backend**: Python, FastAPI, SQLAlchemy (ORM), Pydantic.
*   **Tools**: SQLite/PostgreSQL, JWT, Git, and Pytest for automated testing.

## What I Have Gained
*   **Full-Stack Capability**: I can now build a complete application from the user interface down to the database.
*   **Problem-Solving Skills**: I learned how to debug complex data flows and optimize user interactions.
*   **Confidence**: Developing a feature-rich app from scratch has given me the confidence to take on professional software engineering challenges.

## Why This Project is Important for My Future
This project serves as a professional **star portfolio piece**. It demonstrates my ability to work with modern tech stacks, handle security, manage databases, and design high-quality user experiences—all key skills that top companies look for in developers.
