from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session 
from database import engine, get_db
import models
from routers import auth, posts, users, comments, admin, reports

# Create tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI() 

# Mount uploads directory to serve images
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api")
app.include_router(posts.router, prefix="/api")
app.include_router(users.router, prefix="/api")
app.include_router(comments.router, prefix="/api")
app.include_router(admin.router, prefix="/api")
app.include_router(reports.router, prefix="/api")

@app.get('/api/greet')
async def greet():
    return {"message":"This is BragBoard."}

@app.post("/api/echo")
def echo(data: dict):
    return {"you_sent": data}

@app.get("/")
def read_root():
    return {"message": "Database tables created successfully!"}

# Test the DB connection
@app.get("/test-db")
def test_db(db: Session = Depends(get_db)):
    return {"status": "Database is connected"}
