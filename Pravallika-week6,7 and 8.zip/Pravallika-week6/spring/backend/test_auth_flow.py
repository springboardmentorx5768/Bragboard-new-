from fastapi.testclient import TestClient
from main import app
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from database import Base, get_db
import pytest

# Use a separate test database or the main one if we are confident.
# For safety, let's try to use the configured one but we must be careful not to mess up real data if it exists.
# But since this is a dev environment, maybe it's fine. 
# Better: Use SQLite for testing to avoid dependency on local Postgres being running
# However, the user asked to use the "provided spring folder" which implies using their config.
# Let's try to override the DB dependency for testing to use SQLite in-memory to be safe and robust.

SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def test_register_and_login():
    # Create tables
    Base.metadata.create_all(bind=engine)
    
    # 1. Register
    response = client.post(
        "/api/register",
        json={
            "name": "Test User",
            "email": "test@example.com",
            "password": "password123",
            "department": "IT",
            "role": "employee"
        },
    )
    if response.status_code == 400 and response.json()["detail"] == "Email already registered":
        print("User already exists, proceeding to login test.")
    else:
        assert response.status_code == 200, f"Register failed: {response.text}"
        data = response.json()
        assert data["email"] == "test@example.com"
        assert "id" in data
        print("Registration successful.")

    # 2. Login
    response = client.post(
        "/api/login",
        json={
            "email": "test@example.com",
            "password": "password123"
        },
    )
    assert response.status_code == 200, f"Login failed: {response.text}"
    token_data = response.json()
    assert "access_token" in token_data
    assert token_data["token_type"] == "bearer"
    print("Login successful. Token received.")

    # Clean up (drop tables)
    Base.metadata.drop_all(bind=engine)

if __name__ == "__main__":
    try:
        test_register_and_login()
        print("ALL TESTS PASSED")
    except Exception as e:
        print(f"TEST FAILED: {e}")
