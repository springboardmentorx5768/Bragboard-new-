from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime
from models import UserRole

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    department: Optional[str] = None
    role: UserRole = UserRole.employee

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None

class UserResponse(BaseModel):
    id: int
    name: str
    email: EmailStr
    department: str
    role: UserRole
    avatar_url: Optional[str] = None
    
    class Config:
        orm_mode = True

class ReactionCreate(BaseModel):
    reaction_type: str = "like"

class ReactionResponse(BaseModel):
    id: int
    post_id: int
    user_id: int
    reaction_type: str
    
    class Config:
        orm_mode = True

class UserBasic(BaseModel):
    id: int
    name: str
    email: str
    department: Optional[str]
    avatar_url: Optional[str] = None

    class Config:
        orm_mode = True


class CommentCreate(BaseModel):
    content: str
    parent_id: Optional[int] = None

class CommentResponse(BaseModel):
    id: int
    post_id: int
    user_id: int
    user_name: str
    user_department: Optional[str]
    user_avatar: Optional[str] = None
    content: str
    parent_id: Optional[int]
    created_at: datetime
    replies: list["CommentResponse"] = []

    class Config:
        orm_mode = True

class PostResponse(BaseModel):
    id: int
    title: str
    message: str
    image_url: Optional[str]
    created_at: datetime
    sender_id: int
    sender_name: str
    sender_department: Optional[str]
    sender_avatar: Optional[str] = None
    reaction_count: int = 0
    user_has_reacted: bool = False
    recipients: list[UserBasic] = []
    comments: list[CommentResponse] = []
    
    class Config:
        orm_mode = True

# Required for recursive schemas
CommentResponse.update_forward_refs()

class ReportCreate(BaseModel):
    post_id: Optional[int] = None
    comment_id: Optional[int] = None
    reason: str

class ReportResponse(BaseModel):
    id: int
    post_id: Optional[int]
    comment_id: Optional[int]
    reported_by: int
    reporter_name: str
    reason: str
    status: str
    created_at: datetime
    resolved_at: Optional[datetime] = None
    
    class Config:
        orm_mode = True

class TopContributor(BaseModel):
    user_id: int
    name: str
    department: Optional[str]
    avatar_url: Optional[str]
    post_count: int

class MostTagged(BaseModel):
    user_id: int
    name: str
    department: Optional[str]
    avatar_url: Optional[str]
    tagged_count: int

class LeaderboardEntry(BaseModel):
    user_id: int
    name: str
    department: Optional[str]
    avatar_url: Optional[str]
    points: int
    posts_sent: int
    posts_received: int
    reactions_received: int

