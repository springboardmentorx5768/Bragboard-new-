from sqlalchemy.orm import Session
from datetime import datetime
import models
import schemas

class CommentService:
    @staticmethod
    def create_comment(db: Session, post_id: int, user_id: int, content: str, parent_id: int = None):
        comment = models.Comment(
            post_id=post_id,
            user_id=user_id,
            parent_id=parent_id,
            content=content,
            created_at=datetime.utcnow()
        )
        db.add(comment)
        db.commit()
        db.refresh(comment)
        # Ensure user is loaded for formatting
        _ = comment.user
        return comment

    @staticmethod
    def get_comments_for_post(db: Session, post_id: int):
        # Fetch only top-level comments; replies will be loaded via relationships if needed, 
        # or we can structure it here for the response.
        return db.query(models.Comment).filter(
            models.Comment.post_id == post_id,
            models.Comment.parent_id == None
        ).all()

    @staticmethod
    def format_comment_response(comment: models.Comment) -> dict:
        if not comment:
            return {}
            
        # Ensure user is loaded (e.g. if created in same session)
        if comment.user is None:
            # This should not happen if data integrity is maintained, 
            # but for tests or weird session states, we handle it.
            user_name = "Unknown"
            user_dept = None
            user_avatar = None
        else:
            user_name = comment.user.name
            user_dept = comment.user.department
            user_avatar = comment.user.avatar_url
            
        return {
            "id": comment.id,
            "post_id": comment.post_id,
            "user_id": comment.user_id,
            "user_name": user_name,
            "user_department": user_dept,
            "user_avatar": user_avatar,
            "content": comment.content,
            "parent_id": comment.parent_id,
            "created_at": comment.created_at,
            "replies": [CommentService.format_comment_response(reply) for reply in (comment.replies or [])]
        }
