from sqlalchemy.orm import Session
import models

class UserService:
    @staticmethod
    def get_all_users(db: Session):
        return db.query(models.User).all()

    @staticmethod
    def get_users_by_ids(db: Session, user_ids: list[int]):
        return db.query(models.User).filter(models.User.id.in_(user_ids)).all()

    @staticmethod
    def update_avatar(db: Session, user: models.User, avatar_url: str):
        user.avatar_url = avatar_url
        db.commit()
        db.refresh(user)
        return user
