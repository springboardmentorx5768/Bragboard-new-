from sqlalchemy.orm import Session
from io import BytesIO, StringIO
import csv
from datetime import datetime
import models

class ExportService:
    @staticmethod
    def export_reports_csv(db: Session, status: str = None):
        """Export reports to CSV format"""
        query = db.query(models.Report)
        
        if status:
            query = query.filter(models.Report.status == status)
        
        reports = query.order_by(models.Report.created_at.desc()).all()
        
        # Create CSV in memory
        output = StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow([
            'Report ID', 'Post ID', 'Comment ID', 'Reporter', 
            'Reason', 'Status', 'Created At', 'Resolved At'
        ])
        
        # Write data
        for report in reports:
            writer.writerow([
                report.id,
                report.post_id or '',
                report.comment_id or '',
                report.reporter.name if report.reporter else 'Unknown',
                report.reason,
                report.status.value,
                report.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                report.resolved_at.strftime('%Y-%m-%d %H:%M:%S') if report.resolved_at else ''
            ])
        
        return output.getvalue()
    
    @staticmethod
    def export_reports_pdf(db: Session, status: str = None):
        """Export reports to PDF format"""
        try:
            from reportlab.lib.pagesizes import letter, A4
            from reportlab.lib import colors
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
            from reportlab.lib.units import inch
        except ImportError:
            raise ImportError("reportlab is required for PDF export. Install with: pip install reportlab")
        
        query = db.query(models.Report)
        
        if status:
            query = query.filter(models.Report.status == status)
        
        reports = query.order_by(models.Report.created_at.desc()).all()
        
        # Create PDF in memory
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        elements = []
        
        # Add title
        styles = getSampleStyleSheet()
        title = Paragraph("Reports Export", styles['Title'])
        elements.append(title)
        elements.append(Spacer(1, 0.3*inch))
        
        # Add metadata
        meta = Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal'])
        elements.append(meta)
        elements.append(Spacer(1, 0.2*inch))
        
        # Create table data
        data = [['ID', 'Type', 'Reporter', 'Reason', 'Status', 'Created']]
        
        for report in reports:
            content_type = 'Post' if report.post_id else 'Comment'
            data.append([
                str(report.id),
                content_type,
                report.reporter.name if report.reporter else 'Unknown',
                report.reason[:50] + '...' if len(report.reason) > 50 else report.reason,
                report.status.value,
                report.created_at.strftime('%Y-%m-%d')
            ])
        
        # Create table
        table = Table(data, colWidths=[0.5*inch, 0.8*inch, 1.2*inch, 2.5*inch, 0.8*inch, 1*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
        ]))
        
        elements.append(table)
        
        # Build PDF
        doc.build(elements)
        
        return buffer.getvalue()
