from sqlalchemy.orm import Session
from sqlalchemy import func, desc
import models

class AdminService:
    @staticmethod
    def get_top_contributors(db: Session, limit: int = 10):
        """Get users with the most posts"""
        results = (
            db.query(
                models.User.id,
                models.User.name,
                models.User.department,
                models.User.avatar_url,
                func.count(models.Post.id).label('post_count')
            )
            .join(models.Post, models.User.id == models.Post.sender_id)
            .group_by(models.User.id)
            .order_by(desc('post_count'))
            .limit(limit)
            .all()
        )
        
        return [
            {
                "user_id": r.id,
                "name": r.name,
                "department": r.department,
                "avatar_url": r.avatar_url,
                "post_count": r.post_count
            }
            for r in results
        ]
    
    @staticmethod
    def get_most_tagged(db: Session, limit: int = 10):
        """Get users who are tagged most frequently as recipients"""
        results = (
            db.query(
                models.User.id,
                models.User.name,
                models.User.department,
                models.User.avatar_url,
                func.count(models.ShoutoutRecipient.id).label('tagged_count')
            )
            .join(models.ShoutoutRecipient, models.User.id == models.ShoutoutRecipient.recipient_id)
            .group_by(models.User.id)
            .order_by(desc('tagged_count'))
            .limit(limit)
            .all()
        )
        
        return [
            {
                "user_id": r.id,
                "name": r.name,
                "department": r.department,
                "avatar_url": r.avatar_url,
                "tagged_count": r.tagged_count
            }
            for r in results
        ]
    
    @staticmethod
    def get_leaderboard(db: Session, limit: int = 20):
        """Calculate gamified leaderboard with points"""
        users = db.query(models.User).all()
        leaderboard = []
        
        for user in users:
            # Count posts sent
            posts_sent = db.query(func.count(models.Post.id)).filter(
                models.Post.sender_id == user.id
            ).scalar()
            
            # Count posts received (as recipient)
            posts_received = db.query(func.count(models.ShoutoutRecipient.id)).filter(
                models.ShoutoutRecipient.recipient_id == user.id
            ).scalar()
            
            # Count reactions received on user's posts
            reactions_received = (
                db.query(func.count(models.Reaction.id))
                .join(models.Post, models.Reaction.post_id == models.Post.id)
                .filter(models.Post.sender_id == user.id)
                .scalar()
            )
            
            # Calculate points: posts_sent * 5 + posts_received * 10 + reactions_received * 2
            points = (posts_sent * 5) + (posts_received * 10) + (reactions_received * 2)
            
            if points > 0:  # Only include users with activity
                leaderboard.append({
                    "user_id": user.id,
                    "name": user.name,
                    "department": user.department,
                    "avatar_url": user.avatar_url,
                    "points": points,
                    "posts_sent": posts_sent,
                    "posts_received": posts_received,
                    "reactions_received": reactions_received
                })
        
        # Sort by points descending
        leaderboard.sort(key=lambda x: x['points'], reverse=True)
        return leaderboard[:limit]
    
    @staticmethod
    def delete_any_post(db: Session, post_id: int):
        """Admin delete any post"""
        post = db.query(models.Post).filter(models.Post.id == post_id).first()
        if post:
            db.delete(post)
            db.commit()
            return True
        return False
    
    @staticmethod
    def delete_any_comment(db: Session, comment_id: int):
        """Admin delete any comment"""
        comment = db.query(models.Comment).filter(models.Comment.id == comment_id).first()
        if comment:
            db.delete(comment)
            db.commit()
            return True
        return False
