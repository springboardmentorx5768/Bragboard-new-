from sqlalchemy.orm import Session
from sqlalchemy import desc
import models, schemas
import os
import shutil
from uuid import uuid4
from fastapi import UploadFile

UPLOAD_DIR = "uploads"

class PostService:
    @staticmethod
    def create_post(db: Session, title: str, message: str, user_id: int, image: UploadFile = None, recipient_ids: list[int] = None):
        image_url = None
        if image:
            os.makedirs(UPLOAD_DIR, exist_ok=True)
            filename = f"{uuid4()}_{image.filename}"
            path = os.path.join(UPLOAD_DIR, filename)
            with open(path, "wb") as buffer:
                shutil.copyfileobj(image.file, buffer)
            image_url = f"/uploads/{filename}"

        post = models.Post(
            title=title,
            message=message,
            image_url=image_url,
            sender_id=user_id
        )
        db.add(post)
        db.commit()
        db.refresh(post)

        if recipient_ids:
            for rid in recipient_ids:
                recipient = models.ShoutoutRecipient(post_id=post.id, recipient_id=rid)
                db.add(recipient)
            db.commit()

        return post

    @staticmethod
    def get_posts_filtered(db: Session, current_user_id: int, user_department: str, 
                         filter_department: str = None, filter_sender: int = None, 
                         date_start: str = None, date_end: str = None):
        
        # Base Query: All posts
        query = (
            db.query(models.Post)
            .join(models.User, models.Post.sender_id == models.User.id)
            .outerjoin(models.ShoutoutRecipient, models.ShoutoutRecipient.post_id == models.Post.id)
        )

        # Apply Filters on top of the base query
        if filter_department:
            query = query.filter(models.User.department == filter_department)
        
        if filter_sender:
            query = query.filter(models.Post.sender_id == filter_sender)
        
        if date_start:
            query = query.filter(models.Post.created_at >= date_start)
        
        if date_end:
            # If date_end is a string like 'YYYY-MM-DD', append ' 23:59:59' to include the full day
            if len(date_end) == 10:
                date_end_dt = f"{date_end} 23:59:59"
                query = query.filter(models.Post.created_at <= date_end_dt)
            else:
                query = query.filter(models.Post.created_at <= date_end)

        return (
            query
            .order_by(models.Post.created_at.desc())
            .distinct() 
            .all()
        )

    @staticmethod
    def get_posts_by_department(db: Session, department: str, current_user_id: int):
        # Deprecated wrapper for backward compatibility if needed, using the new method
        return PostService.get_posts_filtered(db, current_user_id, department)

    @staticmethod
    def get_post(db: Session, post_id: int):
        return db.query(models.Post).filter(models.Post.id == post_id).first()

    @staticmethod
    def update_post(db: Session, post: models.Post, title: str = None, message: str = None):
        if title:
            post.title = title
        if message:
            post.message = message
        db.commit()
        db.refresh(post)
        return post

    @staticmethod
    def delete_post(db: Session, post: models.Post):
        if post.image_url:
            try:
                filename = post.image_url.split("/")[-1]
                file_path = os.path.join(UPLOAD_DIR, filename)
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception as e:
                print(f"Error deleting file: {e}")
        
        db.delete(post)
        db.commit()
