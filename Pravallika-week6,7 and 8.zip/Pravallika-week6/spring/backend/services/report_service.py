from sqlalchemy.orm import Session
from datetime import datetime
import models

class ReportService:
    @staticmethod
    def create_report(db: Session, post_id: int, comment_id: int, reported_by: int, reason: str):
        """Create a new report for a post or comment"""
        report = models.Report(
            post_id=post_id,
            comment_id=comment_id,
            reported_by=reported_by,
            reason=reason,
            status=models.ReportStatus.pending
        )
        db.add(report)
        db.commit()
        db.refresh(report)
        return report
    
    @staticmethod
    def get_all_reports(db: Session, status: str = None):
        """Get all reports, optionally filtered by status"""
        query = db.query(models.Report)
        
        if status:
            query = query.filter(models.Report.status == status)
        
        reports = query.order_by(models.Report.created_at.desc()).all()
        
        # Format response with reporter name
        result = []
        for report in reports:
            result.append({
                "id": report.id,
                "post_id": report.post_id,
                "comment_id": report.comment_id,
                "reported_by": report.reported_by,
                "reporter_name": report.reporter.name if report.reporter else "Unknown",
                "reason": report.reason,
                "status": report.status.value,
                "created_at": report.created_at,
                "resolved_at": report.resolved_at
            })
        
        return result
    
    @staticmethod
    def resolve_report(db: Session, report_id: int, admin_id: int, new_status: str):
        """Resolve or dismiss a report"""
        report = db.query(models.Report).filter(models.Report.id == report_id).first()
        
        if not report:
            return None
        
        report.status = new_status
        report.resolved_by = admin_id
        report.resolved_at = datetime.utcnow()
        
        db.commit()
        db.refresh(report)
        return report
