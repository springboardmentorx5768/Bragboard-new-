from sqlalchemy.orm import Session
from sqlalchemy import and_
import models, schemas

class ReactionService:
    @staticmethod
    def toggle_reaction(db: Session, post_id: int, user_id: int, reaction_type: str = "like"):
        # Check if reaction exists
        existing_reaction = db.query(models.Reaction).filter(
            and_(models.Reaction.post_id == post_id, models.Reaction.user_id == user_id)
        ).first()

        if existing_reaction:
            if existing_reaction.reaction_type == reaction_type:
                # If same type exists, remove it (toggle off)
                db.delete(existing_reaction)
                db.commit()
                return {"status": "removed"}
            else:
                # If different type exists, update it (switch type)
                existing_reaction.reaction_type = reaction_type
                db.commit()
                db.refresh(existing_reaction)
                return {"status": "updated", "reaction": existing_reaction}
        else:
            # If not exists, add it (toggle on)
            new_reaction = models.Reaction(
                post_id=post_id,
                user_id=user_id,
                reaction_type=reaction_type
            )
            db.add(new_reaction)
            db.commit()
            db.refresh(new_reaction)
            return {"status": "added", "reaction": new_reaction}

    @staticmethod
    def get_reaction_counts_by_type(db: Session, post_id: int):
        reactions = db.query(models.Reaction).filter(models.Reaction.post_id == post_id).all()
        counts = {"like": 0, "clap": 0, "star": 0}
        for r in reactions:
            if r.reaction_type in counts:
                counts[r.reaction_type] += 1
        return counts

    @staticmethod
    def get_user_reaction(db: Session, post_id: int, user_id: int):
        reaction = db.query(models.Reaction).filter(
            and_(models.Reaction.post_id == post_id, models.Reaction.user_id == user_id)
        ).first()
        return reaction.reaction_type if reaction else None
