import json
from database import SessionLocal
import models
from sqlalchemy import desc

def dump_users_json():
    db = SessionLocal()
    try:
        users = db.query(models.User).order_by(desc(models.User.joined_at)).all()
        user_list = []
        for user in users:
            user_list.append({
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "role": user.role.value,
                "joined_at": str(user.joined_at) if user.joined_at else None
            })
        
        with open("users_dump.json", "w") as f:
            json.dump(user_list, f, indent=2)
            
        print(f"Dumped {len(user_list)} users to users_dump.json")
    finally:
        db.close()

if __name__ == "__main__":
    dump_users_json()
