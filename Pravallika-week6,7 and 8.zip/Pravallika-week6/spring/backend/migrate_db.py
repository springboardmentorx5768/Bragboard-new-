"""
Database migration script to add missing columns to existing database.
Run this script to update the database schema without losing existing data.
"""

import sqlite3
import os

# Path to the database
DB_PATH = "bragboard.db"

def migrate_database():
    if not os.path.exists(DB_PATH):
        print(f"Database {DB_PATH} not found. It will be created automatically when you start the server.")
        return
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # Check if avatar_url column exists in users table
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'avatar_url' not in columns:
            print("Adding avatar_url column to users table...")
            cursor.execute("ALTER TABLE users ADD COLUMN avatar_url VARCHAR")
            print("✓ Added avatar_url column")
        else:
            print("✓ avatar_url column already exists")
        
        # Check if reports table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='reports'")
        if not cursor.fetchone():
            print("Creating reports table...")
            cursor.execute("""
                CREATE TABLE reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    post_id INTEGER,
                    comment_id INTEGER,
                    reported_by INTEGER NOT NULL,
                    reason TEXT NOT NULL,
                    status VARCHAR DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    resolved_at TIMESTAMP,
                    resolved_by INTEGER,
                    FOREIGN KEY (post_id) REFERENCES posts(id),
                    FOREIGN KEY (comment_id) REFERENCES comments(id),
                    FOREIGN KEY (reported_by) REFERENCES users(id),
                    FOREIGN KEY (resolved_by) REFERENCES users(id)
                )
            """)
            print("✓ Created reports table")
        else:
            print("✓ reports table already exists")
        
        conn.commit()
        print("\n✅ Database migration completed successfully!")
        print("You can now restart your backend server.")
        
    except Exception as e:
        print(f"❌ Error during migration: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    print("Starting database migration...\n")
    migrate_database()
