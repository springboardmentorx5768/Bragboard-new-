import time
from fastapi.testclient import TestClient
from main import app
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database import Base, get_db
import os
import json

db_file = f"test_tag_{int(time.time())}.db"
SQLALCHEMY_DATABASE_URL = f"sqlite:///./{db_file}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def test_tagging_flow():
    Base.metadata.create_all(bind=engine)
    
    try:
        # 1. Register User A (Dept IT)
        client.post("/api/register", json={
            "name": "User A",
            "email": "usera@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        token_a = client.post("/api/login", json={"email": "usera@example.com", "password": "password"}).json()["access_token"]
        headers_a = {"Authorization": f"Bearer {token_a}"}
        
        # 2. Register User B (Dept HR) - Different Dept!
        client.post("/api/register", json={
            "name": "User B",
            "email": "userb@example.com",
            "password": "password",
            "department": "HR",
            "role": "employee"
        })
        token_b = client.post("/api/login", json={"email": "userb@example.com", "password": "password"}).json()["access_token"]
        headers_b = {"Authorization": f"Bearer {token_b}"}

        # 3. Register User C (Dept IT) - Same Dept as A
        client.post("/api/register", json={
            "name": "User C",
            "email": "userc@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        token_c = client.post("/api/login", json={"email": "userc@example.com", "password": "password"}).json()["access_token"]
        headers_c = {"Authorization": f"Bearer {token_c}"}
        
        # Get User IDs (Need ID for tagging)
        users = client.get("/api/users/", headers=headers_a).json()
        user_b_id = next(u["id"] for u in users if u["email"] == "userb@example.com")
        
        # 4. Create Post by A, tagging B (Cross-Dept)
        create_res = client.post("/api/posts/", 
            data={
                "title": "Cross Dept Shoutout", 
                "message": "Great work!",
                "recipient_ids": json.dumps([user_b_id])
            }, 
            headers=headers_a
        )
        assert create_res.status_code == 200
        post_id = create_res.json()["id"]
        
        # 5. Verify Post Data as User A (Sender)
        posts_a = client.get("/api/posts/", headers=headers_a).json()
        post = posts_a[0]
        assert len(post["recipients"]) == 1
        assert post["recipients"][0]["email"] == "userb@example.com" if "email" in post["recipients"][0] else True
        assert post["recipients"][0]["name"] == "User B"

        # 6. Verify User B can see it (Tagged, even though different dept)
        posts_b = client.get("/api/posts/", headers=headers_b).json()
        # User B normally sees only HR posts. But this is IT post tagged to B.
        # Logic: (dept match) OR (is tagged)
        assert len(posts_b) == 1
        assert posts_b[0]["id"] == post_id
        
        # 7. Verify User C (IT) can see it (Same Dept as Sender)
        posts_c = client.get("/api/posts/", headers=headers_c).json()
        assert len(posts_c) == 1
        assert posts_c[0]["id"] == post_id

        print("ALL TAGGING TESTS PASSED")

    finally:
        engine.dispose()
        if os.path.exists(db_file):
            try:
                os.remove(db_file)
            except:
                pass

if __name__ == "__main__":
    test_tagging_flow()
