from database import SessionLocal
import models
import auth
import sys

def reset_password(email, new_password):
    db = SessionLocal()
    try:
        user = db.query(models.User).filter(models.User.email == email).first()
        if not user:
            print(f"User with email {email} not found.")
            return

        hashed_password = auth.Hash.make(new_password)
        user.password = hashed_password
        db.commit()
        db.refresh(user)
        print(f"Password for {email} has been reset to '{new_password}'")
        
        # Verify immediately
        if auth.Hash.verify(new_password, user.password):
            print("Verification successful: Password matches hash.")
        else:
            print("Verification failed!")

    except Exception as e:
        print(f"Error: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python fix_password.py <email> <new_password>")
    else:
        reset_password(sys.argv[1], sys.argv[2])
