"""
Script to promote a user to admin role.
Usage: python make_admin.py <email>
"""

import sqlite3
import sys

DB_PATH = "bragboard.db"

def make_admin(email):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # Check if user exists
        cursor.execute("SELECT id, name, email, role FROM users WHERE email = ?", (email,))
        user = cursor.fetchone()
        
        if not user:
            print(f"❌ User with email '{email}' not found!")
            print("\nAvailable users:")
            cursor.execute("SELECT id, name, email, role FROM users")
            for u in cursor.fetchall():
                print(f"  - {u[2]} ({u[1]}) - Role: {u[3]}")
            return
        
        user_id, name, user_email, current_role = user
        
        if current_role == 'admin':
            print(f"✓ User '{name}' ({email}) is already an admin!")
            return
        
        # Update to admin
        cursor.execute("UPDATE users SET role = 'admin' WHERE email = ?", (email,))
        conn.commit()
        
        print(f"✅ Successfully promoted '{name}' ({email}) to admin!")
        print(f"\nPlease logout and login again to see the admin features.")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python make_admin.py <email>")
        print("\nExample: python make_admin.py user@gmail.com")
        
        # Show available users
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, email, role FROM users")
        users = cursor.fetchall()
        conn.close()
        
        if users:
            print("\nAvailable users:")
            for u in users:
                print(f"  - {u[2]} ({u[1]}) - Role: {u[3]}")
    else:
        email = sys.argv[1]
        make_admin(email)
