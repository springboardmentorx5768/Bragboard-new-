from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas
from dependencies import get_current_user
from services.report_service import ReportService

router = APIRouter(prefix="/reports", tags=["Reports"])

@router.post("/")
def create_report(
    report: schemas.ReportCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Create a new report for a post or comment"""
    # Validate that either post_id or comment_id is provided
    if not report.post_id and not report.comment_id:
        raise HTTPException(
            status_code=400, 
            detail="Either post_id or comment_id must be provided"
        )
    
    if report.post_id and report.comment_id:
        raise HTTPException(
            status_code=400, 
            detail="Cannot report both post and comment at the same time"
        )
    
    # Verify the post or comment exists
    if report.post_id:
        post = db.query(models.Post).filter(models.Post.id == report.post_id).first()
        if not post:
            raise HTTPException(status_code=404, detail="Post not found")
    
    if report.comment_id:
        comment = db.query(models.Comment).filter(models.Comment.id == report.comment_id).first()
        if not comment:
            raise HTTPException(status_code=404, detail="Comment not found")
    
    new_report = ReportService.create_report(
        db, 
        report.post_id, 
        report.comment_id, 
        current_user.id, 
        report.reason
    )
    
    return {
        "message": "Report submitted successfully",
        "report_id": new_report.id
    }
