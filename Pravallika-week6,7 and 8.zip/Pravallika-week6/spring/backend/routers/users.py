from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas
from dependencies import get_current_user
from services.user_service import UserService

router = APIRouter(prefix="/users", tags=["Users"])

@router.get("/", response_model=list[schemas.UserBasic])
def get_users(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    # Fetch all users for tagging (or filter if strictly needed, but broad tagging is standard)
    return UserService.get_all_users(db)

@router.get("/me", response_model=schemas.UserResponse)
def read_users_me(current_user: models.User = Depends(get_current_user)):
    return current_user

import os
import shutil
from uuid import uuid4

UPLOAD_DIR = "uploads"

@router.put("/me/avatar")
def update_avatar(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")

    os.makedirs(UPLOAD_DIR, exist_ok=True)
    filename = f"avatar_{uuid4()}_{file.filename}"
    path = os.path.join(UPLOAD_DIR, filename)
    
    with open(path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    avatar_url = f"/uploads/{filename}"
    
    # Optional: Delete old avatar if it exists
    if current_user.avatar_url and current_user.avatar_url.startswith("/uploads/"):
        old_path = os.path.join(UPLOAD_DIR, current_user.avatar_url.split("/")[-1])
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except:
                pass

    UserService.update_avatar(db, current_user, avatar_url)
    return {"message": "Avatar updated successfully", "avatar_url": avatar_url}
