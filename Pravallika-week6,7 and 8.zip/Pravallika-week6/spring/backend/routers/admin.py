from fastapi import APIRouter, Depends, HTTPException, Response
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from database import get_db
import models
from dependencies import get_admin_user, get_current_user
from services.admin_service import AdminService
from services.report_service import ReportService
from services.export_service import ExportService
from io import BytesIO

router = APIRouter(prefix="/admin", tags=["Admin"])

# Analytics Endpoints

@router.get("/analytics/top-contributors")
def get_top_contributors(
    limit: int = 10,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Get top contributors (users with most posts)"""
    return AdminService.get_top_contributors(db, limit)

@router.get("/analytics/most-tagged")
def get_most_tagged(
    limit: int = 10,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Get most tagged users (recipients)"""
    return AdminService.get_most_tagged(db, limit)

@router.get("/leaderboard")
def get_leaderboard(
    limit: int = 20,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """Get gamified leaderboard"""
    return AdminService.get_leaderboard(db, limit)

# Content Moderation Endpoints

@router.delete("/posts/{post_id}")
def admin_delete_post(
    post_id: int,
    db: Session = Depends(get_db),
    admin: models.User = Depends(get_admin_user)
):
    """Admin delete any post"""
    success = AdminService.delete_any_post(db, post_id)
    if not success:
        raise HTTPException(status_code=404, detail="Post not found")
    return {"message": "Post deleted successfully"}

@router.delete("/comments/{comment_id}")
def admin_delete_comment(
    comment_id: int,
    db: Session = Depends(get_db),
    admin: models.User = Depends(get_admin_user)
):
    """Admin delete any comment"""
    success = AdminService.delete_any_comment(db, comment_id)
    if not success:
        raise HTTPException(status_code=404, detail="Comment not found")
    return {"message": "Comment deleted successfully"}

# Reports Management Endpoints

@router.get("/reports")
def get_reports(
    status: str = None,
    db: Session = Depends(get_db),
    admin: models.User = Depends(get_admin_user)
):
    """Get all reports, optionally filtered by status"""
    return ReportService.get_all_reports(db, status)

@router.put("/reports/{report_id}/resolve")
def resolve_report(
    report_id: int,
    new_status: str,
    db: Session = Depends(get_db),
    admin: models.User = Depends(get_admin_user)
):
    """Resolve or dismiss a report"""
    if new_status not in ["resolved", "dismissed"]:
        raise HTTPException(status_code=400, detail="Status must be 'resolved' or 'dismissed'")
    
    report = ReportService.resolve_report(db, report_id, admin.id, new_status)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    return {"message": f"Report {new_status} successfully"}

# Export Endpoints

@router.get("/export/reports/csv")
def export_reports_csv(
    status: str = None,
    db: Session = Depends(get_db),
    admin: models.User = Depends(get_admin_user)
):
    """Export reports as CSV"""
    csv_data = ExportService.export_reports_csv(db, status)
    
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=reports.csv"}
    )

@router.get("/export/reports/pdf")
def export_reports_pdf(
    status: str = None,
    db: Session = Depends(get_db),
    admin: models.User = Depends(get_admin_user)
):
    """Export reports as PDF"""
    try:
        pdf_data = ExportService.export_reports_pdf(db, status)
        
        return Response(
            content=pdf_data,
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=reports.pdf"}
        )
    except ImportError as e:
        raise HTTPException(status_code=500, detail=str(e))
