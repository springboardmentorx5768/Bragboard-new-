from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas
from dependencies import get_current_user
from services.comment_service import CommentService
from services.post_service import PostService

router = APIRouter(prefix="/posts", tags=["Comments"])

@router.post("/{post_id}/comments", response_model=schemas.CommentResponse)
def add_comment(
    post_id: int,
    comment_data: schemas.CommentCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    # If it's a reply, verify parent exists
    if comment_data.parent_id:
        parent = db.query(models.Comment).filter(models.Comment.id == comment_data.parent_id).first()
        if not parent:
            raise HTTPException(status_code=404, detail="Parent comment not found")

    new_comment = CommentService.create_comment(
        db, 
        post_id=post_id, 
        user_id=current_user.id, 
        content=comment_data.content,
        parent_id=comment_data.parent_id
    )
    
    return CommentService.format_comment_response(new_comment)

@router.get("/{post_id}/comments", response_model=list[schemas.CommentResponse])
def get_comments(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    comments = CommentService.get_comments_for_post(db, post_id)
    return [CommentService.format_comment_response(c) for c in comments]
