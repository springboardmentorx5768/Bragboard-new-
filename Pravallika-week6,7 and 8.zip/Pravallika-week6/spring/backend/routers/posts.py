from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas
from dependencies import get_current_user
from services.post_service import PostService
from services.reaction_service import ReactionService
from services.comment_service import CommentService

router = APIRouter(prefix="/posts", tags=["Posts"])

import json

@router.post("/")
def create_post(
    title: str = Form(...),
    message: str = Form(...),
    recipient_ids: str = Form(None), # JSON string of IDs
    image: UploadFile = File(None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    parsed_recipient_ids = []
    if recipient_ids:
        try:
            parsed_recipient_ids = json.loads(recipient_ids)
        except:
            pass # Or raise error

    post = PostService.create_post(db, title, message, current_user.id, image, parsed_recipient_ids)
    return {"message": "Post created successfully", "id": post.id}

@router.get("/")
def get_posts(
    department: str = None,
    sender_id: int = None,
    start_date: str = None,
    end_date: str = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    posts = PostService.get_posts_filtered(
        db, 
        current_user.id, 
        current_user.department,
        filter_department=department,
        filter_sender=sender_id,
        date_start=start_date,
        date_end=end_date
    )
    
    # Enrich with reaction data
    results = []
    for p in posts:
        reaction_counts = ReactionService.get_reaction_counts_by_type(db, p.id)
        user_reaction = ReactionService.get_user_reaction(db, p.id, current_user.id)
        
        results.append({
            "id": p.id,
            "title": p.title,
            "message": p.message,
            "image_url": p.image_url,
            "created_at": p.created_at,
            "sender_id": p.sender_id,
            "sender_name": p.sender.name,
            "sender_department": p.sender.department,
            "sender_avatar": p.sender.avatar_url,
            "reaction_counts": reaction_counts,
            "user_reaction": user_reaction,
            "recipients": [
                {"id": r.recipient.id, "name": r.recipient.name, "department": r.recipient.department, "avatar_url": r.recipient.avatar_url} 
                for r in p.recipients
            ],
            "comments": [CommentService.format_comment_response(c) for c in p.comments if c.parent_id is None]
        })
    return results

@router.delete("/{post_id}")
def delete_post(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    if post.sender_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to delete this post")

    PostService.delete_post(db, post)
    return {"message": "Post deleted successfully"}

@router.put("/{post_id}")
def update_post(
    post_id: int,
    title: str = Form(None),
    message: str = Form(None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    if post.sender_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to edit this post")

    updated_post = PostService.update_post(db, post, title, message)
    return {
        "message": "Post updated successfully",
        "post": {
            "id": updated_post.id,
            "title": updated_post.title,
            "message": updated_post.message
        }
    }

# --- Reaction Endpoints ---

@router.post("/{post_id}/react")
def react_to_post(
    post_id: int,
    reaction_type: str = "like",
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    # Department check
    if post.sender.department != current_user.department:
         raise HTTPException(status_code=403, detail="Cannot react to posts from other departments")

    result = ReactionService.toggle_reaction(db, post_id, current_user.id, reaction_type)
    
    # Return new counts and state
    new_counts = ReactionService.get_reaction_counts_by_type(db, post_id)
    user_reaction = ReactionService.get_user_reaction(db, post_id, current_user.id)
    
    return {
        "message": "Reaction updated",
        "status": result["status"],
        "reaction_counts": new_counts,
        "user_reaction": user_reaction
    }

@router.get("/{post_id}/reactions")
def get_post_reactions(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    reactions = ReactionService.get_reactions_for_post(db, post_id)
    return reactions
