import requests
import json
from datetime import datetime

BASE_URL = "http://localhost:8000/api"

def login(email, password):
    response = requests.post(f"{BASE_URL}/login", json={"email": email, "password": password})
    if response.status_code == 200:
        return response.json()["access_token"]
    else:
        print(f"Login failed for {email}: {response.text}")
        return None

def create_post(token, title, message):
    headers = {"Authorization": f"Bearer {token}"}
    data = {"title": title, "message": message}
    response = requests.post(f"{BASE_URL}/posts/", headers=headers, data=data)
    if response.status_code == 200:
        print(f"Created post: {title}")
        return response.json()
    else:
        print(f"Failed to create post: {response.text}")
        return None

def get_posts(token, filters={}):
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/posts/", headers=headers, params=filters)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Failed to get posts: {response.text}")
        return []

def register(name, email, password, department):
    data = {
        "name": name, 
        "email": email, 
        "password": password, 
        "department": department
    }
    response = requests.post(f"{BASE_URL}/register", json=data)
    if response.status_code == 200:
        print(f"Registered user: {email}")
        return True
    else:
        print(f"Registration failed: {response.text}")
        return False

def main():
    email = "test_filter_v2@example.com"
    password = "password123"
    dept = "Engineering"
    
    # Login as a user
    print("Logging in...")
    token = login(email, password) 
    
    if not token:
        print("Login failed, attempting to register...")
        if register("Test User", email, password, dept):
            token = login(email, password)
    
    if not token:
        print("Could not authenticate. Exiting.")
        return

    print("Running Filter Tests...")
    
    # Create some seed data if empty
    posts = get_posts(token)
    if len(posts) == 0:
        print("Seeding posts...")
        create_post(token, "Post 1", "Message 1")
        create_post(token, "Post 2", "Message 2")
        posts = get_posts(token)

    # 1. Test No Filters
    print(f"No Filter: Found {len(posts)} posts")

    # 2. Test Department Filter (Random Dept)
    dept_filter = dept
    posts = get_posts(token, {"department": dept_filter})
    print(f"Filter Dept '{dept_filter}': Found {len(posts)} posts")
    for p in posts:
        if p['sender_department'] != dept_filter:
            print(f"FAIL: Found post from {p['sender_department']} when filtering by {dept_filter}")

    # 3. Test Sender Filter
    if len(posts) > 0:
        sender_id = posts[0]['sender_id']
        posts = get_posts(token, {"sender_id": sender_id})
        print(f"Filter Sender ID {sender_id}: Found {len(posts)} posts")
        for p in posts:
            if p['sender_id'] != sender_id:
                print(f"FAIL: Found post from {p['sender_id']} when filtering by {sender_id}")

    # 4. Test Date Filter (Today)
    today = datetime.utcnow().date().isoformat()
    posts = get_posts(token, {"start_date": today})
    print(f"Filter Start Date {today}: Found {len(posts)} posts")
    
    # 5. Test Date Filter (Future - should be empty)
    future = "2099-01-01"
    posts = get_posts(token, {"start_date": future})
    print(f"Filter Future Date {future}: Found {len(posts)} posts")
    if len(posts) > 0:
        print("FAIL: Found posts in the future?")

    print("Tests Completed.")

if __name__ == "__main__":
    main()
