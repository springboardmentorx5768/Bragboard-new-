import React, { useState, useEffect } from 'react';

const ReportsView = () => {
    const [reports, setReports] = useState([]);
    const [filter, setFilter] = useState('all');
    const [loading, setLoading] = useState(true);
    const [exporting, setExporting] = useState(false);

    useEffect(() => {
        fetchReports();
    }, [filter]);

    const fetchReports = async () => {
        try {
            const token = localStorage.getItem('token');
            const statusParam = filter !== 'all' ? `?status=${filter}` : '';
            const response = await fetch(`/api/admin/reports${statusParam}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            setReports(data);
        } catch (error) {
            console.error('Error fetching reports:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleResolve = async (reportId, newStatus) => {
        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`/api/admin/reports/${reportId}/resolve?new_status=${newStatus}`, {
                method: 'PUT',
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (response.ok) {
                fetchReports();
            }
        } catch (error) {
            console.error('Error resolving report:', error);
        }
    };

    const handleExport = async (format) => {
        setExporting(true);
        try {
            const token = localStorage.getItem('token');
            const statusParam = filter !== 'all' ? `?status=${filter}` : '';
            const response = await fetch(`/api/admin/export/reports/${format}${statusParam}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `reports.${format}`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error exporting reports:', error);
        } finally {
            setExporting(false);
        }
    };

    if (loading) {
        return <div className="text-center py-8">Loading reports...</div>;
    }

    return (
        <div>
            {/* Header with filters and export */}
            <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-gray-900">🚩 Content Reports</h2>
                    <p className="text-gray-600 mt-1">Review and manage flagged content</p>
                </div>

                <div className="flex gap-2">
                    <button
                        onClick={() => handleExport('csv')}
                        disabled={exporting}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 text-sm font-medium"
                    >
                        📊 Export CSV
                    </button>
                    <button
                        onClick={() => handleExport('pdf')}
                        disabled={exporting}
                        className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 text-sm font-medium"
                    >
                        📄 Export PDF
                    </button>
                </div>
            </div>

            {/* Filter tabs */}
            <div className="mb-6 flex gap-2 border-b border-gray-200">
                {['all', 'pending', 'resolved', 'dismissed'].map(status => (
                    <button
                        key={status}
                        onClick={() => setFilter(status)}
                        className={`
                            px-4 py-2 font-medium text-sm border-b-2 transition-colors
                            ${filter === status
                                ? 'border-indigo-500 text-indigo-600'
                                : 'border-transparent text-gray-500 hover:text-gray-700'
                            }
                        `}
                    >
                        {status.charAt(0).toUpperCase() + status.slice(1)}
                    </button>
                ))}
            </div>

            {/* Reports list */}
            <div className="space-y-4">
                {reports.map(report => (
                    <div key={report.id} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start">
                            <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                    <span className={`
                                        px-2 py-1 rounded-full text-xs font-medium
                                        ${report.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''}
                                        ${report.status === 'resolved' ? 'bg-green-100 text-green-800' : ''}
                                        ${report.status === 'dismissed' ? 'bg-gray-100 text-gray-800' : ''}
                                    `}>
                                        {report.status}
                                    </span>
                                    <span className="text-xs text-gray-500">
                                        {report.post_id ? `Post #${report.post_id}` : `Comment #${report.comment_id}`}
                                    </span>
                                    <span className="text-xs text-gray-500">•</span>
                                    <span className="text-xs text-gray-500">
                                        Reported by {report.reporter_name}
                                    </span>
                                </div>

                                <p className="text-gray-900 font-medium mb-1">Reason:</p>
                                <p className="text-gray-700">{report.reason}</p>

                                <p className="text-xs text-gray-500 mt-2">
                                    {new Date(report.created_at).toLocaleString()}
                                </p>
                            </div>

                            {report.status === 'pending' && (
                                <div className="flex gap-2 ml-4">
                                    <button
                                        onClick={() => handleResolve(report.id, 'resolved')}
                                        className="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 text-sm font-medium"
                                    >
                                        ✓ Resolve
                                    </button>
                                    <button
                                        onClick={() => handleResolve(report.id, 'dismissed')}
                                        className="px-3 py-1 bg-gray-600 text-white rounded hover:bg-gray-700 text-sm font-medium"
                                    >
                                        ✗ Dismiss
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>

            {reports.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                    No {filter !== 'all' ? filter : ''} reports found.
                </div>
            )}
        </div>
    );
};

export default ReportsView;
