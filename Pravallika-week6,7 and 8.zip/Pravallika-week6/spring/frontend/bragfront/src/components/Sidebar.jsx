import React from "react";
import { NavLink } from "react-router-dom";

export default function Sidebar({ open }) {
    const base = "flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 mb-1";
    const activeClass = "bg-indigo-50 text-indigo-700";
    const inactiveClass = "text-gray-600 hover:bg-gray-50 hover:text-gray-900";

    return (
        <aside className={`${open ? "translate-x-0" : "-translate-x-full"} sm:translate-x-0 transform top-0 left-0 w-64 bg-white border-r h-full fixed sm:static transition-transform duration-300 ease-in-out z-20 pt-16 sm:pt-0`}>
            <div className="h-full flex flex-col justify-between">
                <div className="px-3 py-6">
                    <nav className="space-y-1">
                        <NavLink to="/dashboard" className={({ isActive }) => `${base} ${isActive ? activeClass : inactiveClass}`}>
                            <svg className="mr-3 h-5 w-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                            </svg>
                            Dashboard
                        </NavLink>
                        <NavLink to="/create-post" className={({ isActive }) => `${base} ${isActive ? activeClass : inactiveClass}`}>
                            <svg className="mr-3 h-5 w-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                            </svg>
                            Create Post
                        </NavLink>
                        <NavLink to="/profile" className={({ isActive }) => `${base} ${isActive ? activeClass : inactiveClass}`}>
                            <svg className="mr-3 h-5 w-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            Profile
                        </NavLink>
                    </nav>
                </div>
            </div>
        </aside>
    );
}
