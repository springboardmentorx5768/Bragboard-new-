import React, { useState } from 'react';

export default function CommentItem({ comment, onReply, currentUser, isAdmin }) {
    const [isReplying, setIsReplying] = useState(false);
    const [replyContent, setReplyContent] = useState('');

    const isOwner = currentUser && comment.user_id === currentUser.id;

    const formatDate = (dateString) => {
        if (!dateString) return '';
        try {
            return new Date(dateString).toLocaleDateString(undefined, {
                month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            });
        } catch (e) { return dateString }
    };

    const handleReplySubmit = (e) => {
        e.preventDefault();
        if (!replyContent.trim()) return;
        onReply(comment.id, replyContent);
        setReplyContent('');
        setIsReplying(false);
    };

    const handleDeleteClick = async () => {
        if (window.confirm(isAdmin && !isOwner ? "ADMIN: Delete this comment?" : "Delete your comment?")) {
            try {
                const token = localStorage.getItem('token');
                const endpoint = isAdmin && !isOwner
                    ? `/api/admin/comments/${comment.id}`
                    : `/api/comments/${comment.id}`;

                const res = await fetch(endpoint, {
                    method: 'DELETE',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (res.ok) {
                    window.location.reload(); // Simplest way to reflect comment deletion in nested tree
                }
            } catch (e) { console.error(e); }
        }
    };

    return (
        <div className="mt-4 border-l-2 border-indigo-50 pl-4 py-2 group/comment">
            <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                    <img
                        src={comment.user_avatar || "/default_avatar.png"}
                        alt={comment.user_name}
                        className="w-8 h-8 rounded-full border border-gray-100 shadow-sm object-cover"
                    />
                </div>
                <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                        <div>
                            <span className="text-sm font-semibold text-gray-900">{comment.user_name}</span>
                            <span className="ml-2 text-[10px] text-gray-400 font-medium uppercase tracking-wider">{comment.user_department}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                            <span className="text-[10px] text-gray-400 whitespace-nowrap">{formatDate(comment.created_at)}</span>

                            {(isOwner || isAdmin) && (
                                <button
                                    onClick={handleDeleteClick}
                                    className={`opacity-0 group-hover/comment:opacity-100 transition-opacity p-1 rounded-md ${isAdmin && !isOwner ? 'text-red-400 hover:bg-red-50' : 'text-gray-300 hover:text-red-500 hover:bg-gray-50'}`}
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                </button>
                            )}
                        </div>
                    </div>
                    <p className="mt-1 text-sm text-gray-600 leading-relaxed font-light">{comment.content}</p>

                    <div className="flex items-center space-x-4 mt-2">
                        <button
                            onClick={() => setIsReplying(!isReplying)}
                            className="text-[10px] font-bold text-indigo-500 hover:text-indigo-700 uppercase tracking-tighter transition-colors"
                        >
                            {isReplying ? 'Cancel' : 'Reply'}
                        </button>
                    </div>

                    {isReplying && (
                        <form onSubmit={handleReplySubmit} className="mt-2 flex items-center space-x-2">
                            <input
                                type="text"
                                value={replyContent}
                                onChange={(e) => setReplyContent(e.target.value)}
                                placeholder="Write a reply..."
                                className="flex-1 bg-gray-50 border border-gray-100 rounded-full px-4 py-1.5 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none placeholder-gray-400 transition-all"
                                autoFocus
                            />
                            <button
                                type="submit"
                                disabled={!replyContent.trim()}
                                className="p-1.5 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-sm"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                                </svg>
                            </button>
                        </form>
                    )}

                    {comment.replies && comment.replies.length > 0 && (
                        <div className="mt-2 space-y-1">
                            {comment.replies.map((reply) => (
                                <CommentItem
                                    key={reply.id}
                                    comment={reply}
                                    onReply={onReply}
                                    currentUser={currentUser}
                                    isAdmin={isAdmin}
                                />
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
