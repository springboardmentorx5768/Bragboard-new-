import React, { useState } from 'react';
import CommentItem from './CommentItem';

export default function CommentSection({ postId, initialComments, currentUser }) {
    const [comments, setComments] = useState(initialComments || []);
    const [newComment, setNewComment] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e, parentId = null, content = null) => {
        if (e) e.preventDefault();

        const finalContent = content || newComment;
        if (!finalContent.trim()) return;

        setIsLoading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/posts/${postId}/comments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    content: finalContent,
                    parent_id: parentId
                })
            });

            if (res.ok) {
                const addedComment = await res.json();
                if (parentId) {
                    // Update nested comments
                    const addReplyToComments = (list) => {
                        return list.map(c => {
                            if (c.id === parentId) {
                                return { ...c, replies: [...(c.replies || []), addedComment] };
                            } else if (c.replies && c.replies.length > 0) {
                                return { ...c, replies: addReplyToComments(c.replies) };
                            }
                            return c;
                        });
                    };
                    setComments(prev => addReplyToComments(prev));
                } else {
                    // Update top-level comments
                    setComments(prev => [...prev, addedComment]);
                    setNewComment('');
                }
            } else {
                console.error("Failed to add comment");
            }
        } catch (error) {
            console.error("Error adding comment:", error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="mt-6 pt-6 border-t border-gray-50">
            <div className="flex items-center space-x-2 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Comments ({comments.reduce((acc, c) => acc + 1 + (c.replies ? c.replies.length : 0), 0)})</h4>
            </div>

            <form onSubmit={handleSubmit} className="mb-6 flex items-center space-x-3">
                <div className="flex-shrink-0">
                    <img
                        src={currentUser?.avatar_url || "/default_avatar.png"}
                        alt={currentUser?.name || "User"}
                        className="w-8 h-8 rounded-full border border-gray-100 shadow-sm object-cover"
                    />
                </div>
                <div className="flex-1 relative">
                    <input
                        type="text"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Share your thoughts..."
                        className="w-full bg-gray-50 border border-gray-100 rounded-full px-5 py-2 text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-none placeholder-gray-400 transition-all"
                    />
                    <button
                        type="submit"
                        disabled={!newComment.trim() || isLoading}
                        className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-sm"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                        </svg>
                    </button>
                </div>
            </form>

            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                {comments.length > 0 ? (
                    comments.map((comment) => (
                        <CommentItem
                            key={comment.id}
                            comment={comment}
                            currentUser={currentUser}
                            onReply={(parentId, content) => handleSubmit(null, parentId, content)}
                            isAdmin={currentUser?.role === 'admin'}
                        />
                    ))
                ) : (
                    <p className="text-center py-4 text-xs text-gray-400 italic">No comments yet. Be the first to cheer!</p>
                )}
            </div>
        </div>
    );
}
