import React, { useState } from "react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import { useLocation } from "react-router-dom";

export default function Layout({ children }) {
    const [open, setOpen] = useState(false);
    const location = useLocation();

    // Use a user context or prop here. For now, reading from localStorage or a mock
    // In a real app, this should come from AuthContext
    const [user, setUser] = useState({ name: "User" }); // Placeholder, Dashboard fetches real user

    // We can pass the real user object up from Dashboard if we lift state, 
    // but for this structure, we might want to fetch user in Layout or Context.
    // Let's rely on the components fetching their data or Context.
    // For the Navbar "Welcome", we'll implement a simple fetch in Layout if not passed.

    React.useEffect(() => {
        const fetchUser = async () => {
            const token = localStorage.getItem('token');
            if (token) {
                try {
                    const response = await fetch('/api/users/me', {
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    if (response.ok) {
                        const data = await response.json();
                        setUser(data);
                    }
                } catch (e) { }
            }
        };
        fetchUser();
    }, [location.pathname]); // Re-fetch on route change to be safe

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            <Navbar onToggleSidebar={() => setOpen(v => !v)} user={user} />
            <div className="flex flex-1 relative">
                <Sidebar open={open} />

                {/* Overlay for mobile sidebar */}
                {open && (
                    <div
                        className="fixed inset-0 bg-black bg-opacity-50 z-10 sm:hidden"
                        onClick={() => setOpen(false)}
                    ></div>
                )}

                <main className="flex-1 w-full p-4 sm:p-8 overflow-y-auto">
                    {children}
                </main>
            </div>
        </div>
    );
}
