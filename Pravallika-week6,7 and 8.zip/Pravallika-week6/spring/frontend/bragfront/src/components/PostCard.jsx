import React, { useState } from "react";
import CommentSection from "./CommentSection";
import ReportButton from "./ReportButton";

export default function PostCard({ post, user, onDelete, onEdit }) {
    // Format date nicely
    const formatDate = (dateString) => {
        if (!dateString) return '';
        try {
            return new Date(dateString).toLocaleDateString(undefined, {
                month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            });
        } catch (e) { return dateString }
    };

    const isOwner = user && post.sender_id === user.id;
    const isAdmin = user && user.role === 'admin';

    // Multi-Reaction State
    const [userReaction, setUserReaction] = React.useState(post.user_reaction || null);
    const [counts, setCounts] = React.useState(post.reaction_counts || { like: 0, clap: 0, star: 0 });
    const [reacting, setReacting] = React.useState(false);
    const [showComments, setShowComments] = useState(false);

    const handleReaction = async (type) => {
        if (reacting) return;
        setReacting(true);

        // Optimistic Update
        const prevUserReaction = userReaction;
        const prevCounts = { ...counts };

        let newCounts = { ...counts };
        let newUserReaction = null;

        if (userReaction === type) {
            newCounts[type] = Math.max(0, newCounts[type] - 1);
            newUserReaction = null;
        } else {
            if (userReaction) {
                newCounts[userReaction] = Math.max(0, newCounts[userReaction] - 1);
            }
            newCounts[type] += 1;
            newUserReaction = type;
        }

        setCounts(newCounts);
        setUserReaction(newUserReaction);

        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/posts/${post.id}/react?reaction_type=${type}`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (res.ok) {
                const data = await res.json();
                setCounts(data.reaction_counts);
                setUserReaction(data.user_reaction);
            } else {
                setCounts(prevCounts);
                setUserReaction(prevUserReaction);
            }
        } catch (error) {
            setCounts(prevCounts);
            setUserReaction(prevUserReaction);
        } finally {
            setReacting(false);
        }
    };

    const handleDeleteClick = () => {
        const msg = isAdmin && !isOwner
            ? "ADMIN ACTION: Are you sure you want to delete this post as an administrator?"
            : "Are you sure you want to delete this post?";

        if (window.confirm(msg)) {
            onDelete(post.id);
        }
    };

    return (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all duration-300 group">
            <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                    <img
                        src={post.sender_avatar || "/default_avatar.png"}
                        alt={post.sender_name}
                        className="w-12 h-12 rounded-full border border-gray-100 shadow-sm object-cover"
                    />
                </div>
                <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm font-black text-gray-900 truncate">
                                {post.sender_name}
                                {post.recipients && post.recipients.length > 0 && (
                                    <span className="font-medium text-gray-400">
                                        {' '}recognized{' '}
                                        {post.recipients.map((r, i) => (
                                            <span key={r.id}>
                                                {i > 0 && ", "}
                                                <span className="text-indigo-600">@{r.name}</span>
                                            </span>
                                        ))}
                                    </span>
                                )}
                            </p>
                            <p className="text-[10px] text-indigo-500 font-black uppercase tracking-widest">{post.sender_department}</p>
                        </div>
                        <div className="flex items-center space-x-3">
                            <span className="text-[10px] text-gray-400 font-medium whitespace-nowrap">{formatDate(post.created_at)}</span>

                            <div className="flex items-center bg-gray-50 rounded-full px-2 py-1 space-x-1 border border-gray-100">
                                <button
                                    onClick={() => handleReaction('like')}
                                    className={`flex items-center space-x-1 p-1 rounded-full transition-colors ${userReaction === 'like' ? 'text-pink-600 bg-pink-100' : 'text-gray-400 hover:text-pink-500 hover:bg-white'}`}
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill={userReaction === 'like' ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                                    </svg>
                                    {counts.like > 0 && <span className="text-[10px] font-bold">{counts.like}</span>}
                                </button>
                                <button
                                    onClick={() => handleReaction('clap')}
                                    className={`flex items-center space-x-1 p-1 rounded-full transition-colors ${userReaction === 'clap' ? 'text-yellow-600 bg-yellow-100' : 'text-gray-400 hover:text-yellow-500 hover:bg-white'}`}
                                >
                                    <span className="text-sm">👏</span>
                                    {counts.clap > 0 && <span className="text-[10px] font-bold">{counts.clap}</span>}
                                </button>
                                <button
                                    onClick={() => handleReaction('star')}
                                    className={`flex items-center space-x-1 p-1 rounded-full transition-colors ${userReaction === 'star' ? 'text-blue-600 bg-blue-100' : 'text-gray-400 hover:text-blue-500 hover:bg-white'}`}
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill={userReaction === 'star' ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.382-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                                    </svg>
                                    {counts.star > 0 && <span className="text-[10px] font-bold">{counts.star}</span>}
                                </button>
                            </div>

                            <button
                                onClick={() => setShowComments(!showComments)}
                                className={`flex items-center space-x-1 p-2 rounded-xl transition-all ${showComments ? 'text-indigo-600 bg-indigo-50 border-indigo-100 shadow-sm' : 'text-gray-400 hover:text-indigo-500 hover:bg-indigo-50 border-transparent'} border`}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill={showComments ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                </svg>
                                <span className="text-xs font-bold">{post.comments?.length || 0}</span>
                            </button>

                            {(isOwner || isAdmin) && (
                                <div className="flex items-center space-x-1 border-l border-gray-100 pl-2">
                                    {isOwner && (
                                        <button
                                            onClick={() => onEdit(post)}
                                            className="text-gray-300 hover:text-indigo-600 transition-colors p-1.5 rounded-lg hover:bg-indigo-50"
                                            title="Edit Post"
                                        >
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                            </svg>
                                        </button>
                                    )}
                                    <button
                                        onClick={handleDeleteClick}
                                        className={`transition-colors p-1.5 rounded-lg ${isAdmin && !isOwner ? 'text-red-400 bg-red-50 hover:bg-red-100 hover:text-red-600' : 'text-gray-300 hover:text-red-600 hover:bg-red-50'}`}
                                        title={isAdmin && !isOwner ? "Admin Delete" : "Delete Post"}
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                        </svg>
                                    </button>
                                </div>
                            )}

                            {!isOwner && (
                                <div className="border-l border-gray-100 pl-2">
                                    <ReportButton postId={post.id} />
                                </div>
                            )}
                        </div>
                    </div>

                    <h3 className="mt-3 text-lg font-bold text-gray-900 leading-snug tracking-tight">{post.title}</h3>
                    <p className="mt-2 text-gray-600 text-sm leading-relaxed antialiased">{post.message}</p>

                    {post.image_url && (
                        <div className="mt-5 relative group/img">
                            <div className="rounded-2xl overflow-hidden border border-gray-100 shadow-sm transition-all duration-500 group-hover/img:shadow-xl">
                                <img
                                    className="w-full h-auto object-cover max-h-[500px]"
                                    src={post.image_url}
                                    alt="post attachment"
                                    loading="lazy"
                                />
                            </div>
                        </div>
                    )}

                    {showComments && (
                        <div className="mt-6">
                            <CommentSection
                                postId={post.id}
                                initialComments={post.comments}
                                currentUser={user}
                            />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
