import React, { useState, useEffect } from 'react';

const ContentModerationView = () => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchAllPosts();
    }, []);

    const fetchAllPosts = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await fetch('/api/posts/', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            setPosts(data);
        } catch (error) {
            console.error('Error fetching posts:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDeletePost = async (postId) => {
        if (!window.confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
            return;
        }

        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`/api/admin/posts/${postId}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (response.ok) {
                setPosts(posts.filter(p => p.id !== postId));
            }
        } catch (error) {
            console.error('Error deleting post:', error);
        }
    };

    const handleDeleteComment = async (postId, commentId) => {
        if (!window.confirm('Are you sure you want to delete this comment? This action cannot be undone.')) {
            return;
        }

        try {
            const token = localStorage.getItem('token');
            const response = await fetch(`/api/admin/comments/${commentId}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (response.ok) {
                // Refresh posts to update comments
                fetchAllPosts();
            }
        } catch (error) {
            console.error('Error deleting comment:', error);
        }
    };

    if (loading) {
        return <div className="text-center py-8">Loading content...</div>;
    }

    return (
        <div>
            <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900">🛡️ Content Moderation</h2>
                <p className="text-gray-600 mt-1">Manage and delete posts or comments</p>
            </div>

            <div className="space-y-6">
                {posts.map(post => (
                    <div key={post.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                        {/* Post Header */}
                        <div className="flex justify-between items-start mb-4">
                            <div className="flex items-center space-x-3">
                                {post.sender_avatar ? (
                                    <img
                                        src={post.sender_avatar}
                                        alt={post.sender_name}
                                        className="h-10 w-10 rounded-full object-cover"
                                    />
                                ) : (
                                    <div className="h-10 w-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold">
                                        {post.sender_name.charAt(0).toUpperCase()}
                                    </div>
                                )}
                                <div>
                                    <p className="font-semibold text-gray-900">{post.sender_name}</p>
                                    <p className="text-xs text-gray-500">{post.sender_department}</p>
                                </div>
                            </div>

                            <button
                                onClick={() => handleDeletePost(post.id)}
                                className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 text-sm font-medium"
                            >
                                🗑️ Delete Post
                            </button>
                        </div>

                        {/* Post Content */}
                        <div className="mb-4">
                            <h3 className="text-lg font-bold text-gray-900 mb-2">{post.title}</h3>
                            <p className="text-gray-700">{post.message}</p>
                            {post.image_url && (
                                <img
                                    src={post.image_url}
                                    alt="Post"
                                    className="mt-3 rounded-lg max-h-64 object-cover"
                                />
                            )}
                        </div>

                        {/* Post Meta */}
                        <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                            <span>Post ID: #{post.id}</span>
                            <span>•</span>
                            <span>{new Date(post.created_at).toLocaleDateString()}</span>
                            <span>•</span>
                            <span>{post.comments?.length || 0} comments</span>
                        </div>

                        {/* Comments */}
                        {post.comments && post.comments.length > 0 && (
                            <div className="border-t border-gray-200 pt-4 mt-4">
                                <p className="font-semibold text-gray-900 mb-3">Comments:</p>
                                <div className="space-y-3">
                                    {post.comments.map(comment => (
                                        <div key={comment.id} className="bg-gray-50 rounded-lg p-3">
                                            <div className="flex justify-between items-start">
                                                <div className="flex-1">
                                                    <div className="flex items-center gap-2 mb-1">
                                                        <p className="font-medium text-sm text-gray-900">{comment.user_name}</p>
                                                        <span className="text-xs text-gray-500">•</span>
                                                        <span className="text-xs text-gray-500">
                                                            {new Date(comment.created_at).toLocaleString()}
                                                        </span>
                                                    </div>
                                                    <p className="text-sm text-gray-700">{comment.content}</p>
                                                </div>
                                                <button
                                                    onClick={() => handleDeleteComment(post.id, comment.id)}
                                                    className="ml-2 px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-xs"
                                                >
                                                    Delete
                                                </button>
                                            </div>

                                            {/* Nested Replies */}
                                            {comment.replies && comment.replies.length > 0 && (
                                                <div className="ml-6 mt-2 space-y-2">
                                                    {comment.replies.map(reply => (
                                                        <div key={reply.id} className="bg-white rounded p-2">
                                                            <div className="flex justify-between items-start">
                                                                <div className="flex-1">
                                                                    <div className="flex items-center gap-2 mb-1">
                                                                        <p className="font-medium text-xs text-gray-900">{reply.user_name}</p>
                                                                        <span className="text-xs text-gray-500">
                                                                            {new Date(reply.created_at).toLocaleString()}
                                                                        </span>
                                                                    </div>
                                                                    <p className="text-xs text-gray-700">{reply.content}</p>
                                                                </div>
                                                                <button
                                                                    onClick={() => handleDeleteComment(post.id, reply.id)}
                                                                    className="ml-2 px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-xs"
                                                                >
                                                                    Delete
                                                                </button>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </div>

            {posts.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                    No posts found.
                </div>
            )}
        </div>
    );
};

export default ContentModerationView;
