import React, { useState, useEffect } from 'react';

const LeaderboardView = () => {
    const [leaderboard, setLeaderboard] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchLeaderboard();
    }, []);

    const fetchLeaderboard = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await fetch('/api/admin/leaderboard', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await response.json();
            setLeaderboard(data);
        } catch (error) {
            console.error('Error fetching leaderboard:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="text-center py-8">Loading leaderboard...</div>;
    }

    const getMedalEmoji = (index) => {
        if (index === 0) return '🥇';
        if (index === 1) return '🥈';
        if (index === 2) return '🥉';
        return `${index + 1}.`;
    };

    return (
        <div>
            <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900">🏆 Appreciation Leaderboard</h2>
                <p className="text-gray-600 mt-2">Gamified rankings based on activity and appreciation</p>
                <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <p className="text-sm text-blue-800">
                        <strong>Points System:</strong> Posts Sent (5 pts) + Posts Received (10 pts) + Reactions Received (2 pts)
                    </p>
                </div>
            </div>

            <div className="space-y-3">
                {leaderboard.map((entry, index) => (
                    <div
                        key={entry.user_id}
                        className={`
                            rounded-lg p-4 border-2 transition-all duration-200 hover:shadow-md
                            ${index < 3
                                ? 'bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-300'
                                : 'bg-white border-gray-200'
                            }
                        `}
                    >
                        <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 flex-1">
                                {/* Rank */}
                                <div className="text-2xl font-bold w-12 text-center">
                                    {getMedalEmoji(index)}
                                </div>

                                {/* Avatar */}
                                <div className="flex-shrink-0">
                                    {entry.avatar_url ? (
                                        <img
                                            src={entry.avatar_url}
                                            alt={entry.name}
                                            className="h-14 w-14 rounded-full object-cover border-2 border-gray-300"
                                        />
                                    ) : (
                                        <div className="h-14 w-14 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold text-xl border-2 border-gray-300">
                                            {entry.name.charAt(0).toUpperCase()}
                                        </div>
                                    )}
                                </div>

                                {/* User Info */}
                                <div className="flex-1 min-w-0">
                                    <p className="text-lg font-semibold text-gray-900 truncate">
                                        {entry.name}
                                    </p>
                                    <p className="text-sm text-gray-500 truncate">{entry.department}</p>
                                </div>

                                {/* Stats */}
                                <div className="hidden md:flex items-center space-x-6 text-sm">
                                    <div className="text-center">
                                        <p className="font-semibold text-gray-900">{entry.posts_sent}</p>
                                        <p className="text-gray-500">Sent</p>
                                    </div>
                                    <div className="text-center">
                                        <p className="font-semibold text-gray-900">{entry.posts_received}</p>
                                        <p className="text-gray-500">Received</p>
                                    </div>
                                    <div className="text-center">
                                        <p className="font-semibold text-gray-900">{entry.reactions_received}</p>
                                        <p className="text-gray-500">Reactions</p>
                                    </div>
                                </div>

                                {/* Total Points */}
                                <div className="flex-shrink-0">
                                    <div className={`
                                        px-4 py-2 rounded-full font-bold text-lg
                                        ${index < 3
                                            ? 'bg-gradient-to-r from-yellow-400 to-orange-400 text-white'
                                            : 'bg-indigo-600 text-white'
                                        }
                                    `}>
                                        {entry.points} pts
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Mobile Stats */}
                        <div className="md:hidden mt-3 pt-3 border-t border-gray-200 flex justify-around text-sm">
                            <div className="text-center">
                                <p className="font-semibold text-gray-900">{entry.posts_sent}</p>
                                <p className="text-gray-500">Sent</p>
                            </div>
                            <div className="text-center">
                                <p className="font-semibold text-gray-900">{entry.posts_received}</p>
                                <p className="text-gray-500">Received</p>
                            </div>
                            <div className="text-center">
                                <p className="font-semibold text-gray-900">{entry.reactions_received}</p>
                                <p className="text-gray-500">Reactions</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {leaderboard.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                    No activity yet. Leaderboard will populate as users interact with the platform.
                </div>
            )}
        </div>
    );
};

export default LeaderboardView;
