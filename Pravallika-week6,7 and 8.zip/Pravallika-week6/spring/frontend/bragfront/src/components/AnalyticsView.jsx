import React, { useState, useEffect } from 'react';

const AnalyticsView = () => {
    const [topContributors, setTopContributors] = useState([]);
    const [mostTagged, setMostTagged] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchAnalytics();
    }, []);

    const fetchAnalytics = async () => {
        try {
            const token = localStorage.getItem('token');

            const [contributorsRes, taggedRes] = await Promise.all([
                fetch('/api/admin/analytics/top-contributors', {
                    headers: { 'Authorization': `Bearer ${token}` }
                }),
                fetch('/api/admin/analytics/most-tagged', {
                    headers: { 'Authorization': `Bearer ${token}` }
                })
            ]);

            const contributors = await contributorsRes.json();
            const tagged = await taggedRes.json();

            setTopContributors(contributors);
            setMostTagged(tagged);
        } catch (error) {
            console.error('Error fetching analytics:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="text-center py-8">Loading analytics...</div>;
    }

    return (
        <div className="space-y-8">
            {/* Top Contributors */}
            <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">📈 Top Contributors</h2>
                <p className="text-gray-600 mb-4">Users who have created the most shout-outs</p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {topContributors.map((user, index) => (
                        <div key={user.user_id} className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg p-4 border border-indigo-200">
                            <div className="flex items-center space-x-3">
                                <div className="flex-shrink-0">
                                    {user.avatar_url ? (
                                        <img
                                            src={user.avatar_url}
                                            alt={user.name}
                                            className="h-12 w-12 rounded-full object-cover"
                                        />
                                    ) : (
                                        <div className="h-12 w-12 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold">
                                            {user.name.charAt(0).toUpperCase()}
                                        </div>
                                    )}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-gray-900 truncate">
                                        {index + 1}. {user.name}
                                    </p>
                                    <p className="text-xs text-gray-500 truncate">{user.department}</p>
                                </div>
                                <div className="flex-shrink-0">
                                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-600 text-white">
                                        {user.post_count} posts
                                    </span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Most Tagged */}
            <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">🏅 Most Appreciated</h2>
                <p className="text-gray-600 mb-4">Users who are tagged most frequently in shout-outs</p>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {mostTagged.map((user, index) => (
                        <div key={user.user_id} className="bg-gradient-to-br from-green-50 to-teal-50 rounded-lg p-4 border border-green-200">
                            <div className="flex items-center space-x-3">
                                <div className="flex-shrink-0">
                                    {user.avatar_url ? (
                                        <img
                                            src={user.avatar_url}
                                            alt={user.name}
                                            className="h-12 w-12 rounded-full object-cover"
                                        />
                                    ) : (
                                        <div className="h-12 w-12 rounded-full bg-green-600 flex items-center justify-center text-white font-bold">
                                            {user.name.charAt(0).toUpperCase()}
                                        </div>
                                    )}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-gray-900 truncate">
                                        {index + 1}. {user.name}
                                    </p>
                                    <p className="text-xs text-gray-500 truncate">{user.department}</p>
                                </div>
                                <div className="flex-shrink-0">
                                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-600 text-white">
                                        {user.tagged_count} tags
                                    </span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default AnalyticsView;
