import React, { useEffect, useState } from "react";
import PostCard from "../components/PostCard";
import EditPostModal from "../components/EditPostModal";
import LeaderboardView from "../components/LeaderboardView";
import AnalyticsView from "../components/AnalyticsView";
import { Link } from "react-router-dom";

export default function Dashboard() {
    const [user, setUser] = useState(null);
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [editingPost, setEditingPost] = useState(null);

    // Filter States
    const [filterDept, setFilterDept] = useState("");
    const [filterSender, setFilterSender] = useState("");
    const [dateStart, setDateStart] = useState("");
    const [dateEnd, setDateEnd] = useState("");

    // Users list for sender filter
    const [users, setUsers] = useState([]);


    // Fetch Initial Data (User & Users List)
    useEffect(() => {
        const fetchInitialData = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                window.location.href = '/login';
                return;
            }

            try {
                // Fetch User
                const userRes = await fetch('/api/users/me', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (userRes.ok) {
                    const userData = await userRes.json();
                    setUser(userData);
                }

                // Fetch Users for Filter
                const usersRes = await fetch('/api/users/', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (usersRes.ok) {
                    const usersData = await usersRes.json();
                    setUsers(usersData);
                }

            } catch (error) {
                console.error("Failed to fetch initial data", error);
            }
        };
        fetchInitialData();
    }, []);


    // Fetch Posts with Filters
    useEffect(() => {
        const fetchPosts = async () => {
            const token = localStorage.getItem('token');
            if (!token) return;

            setLoading(true);
            try {
                const queryParams = new URLSearchParams();
                if (filterDept) queryParams.append("department", filterDept);
                if (filterSender) queryParams.append("sender_id", filterSender);
                if (dateStart) queryParams.append("start_date", dateStart);
                if (dateEnd) queryParams.append("end_date", dateEnd);

                const postsRes = await fetch(`/api/posts/?${queryParams.toString()}`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });

                if (postsRes.ok) {
                    const postsData = await postsRes.json();
                    setPosts(postsData);
                } else {
                    console.error("Failed to fetch posts");
                    setPosts([]);
                }

            } catch (error) {
                console.error("Failed to fetch posts", error);
                setPosts([]);
            } finally {
                setLoading(false);
            }
        };
        fetchPosts();
    }, [filterDept, filterSender, dateStart, dateEnd]);

    const handleDeletePost = async (postId) => {
        const token = localStorage.getItem('token');
        try {
            const res = await fetch(`/api/posts/${postId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (res.ok) {
                setPosts(posts.filter(p => p.id !== postId));
            } else {
                alert("Failed to delete post.");
            }
        } catch (error) {
            console.error("Error deleting post:", error);
            alert("Error deleting post.");
        }
    };

    const handleUpdatePost = async (postId, title, message) => {
        const token = localStorage.getItem('token');
        const formData = new FormData();
        formData.append('title', title);
        formData.append('message', message);

        try {
            const res = await fetch(`/api/posts/${postId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            if (res.ok) {
                await res.json();
                // Update local state is tricky with filters, easiest to refetch or update in place
                setPosts(posts.map(p => p.id === postId ? { ...p, title, message } : p));
                setEditingPost(null);
            } else {
                alert("Failed to update post.");
            }
        } catch (error) {
            console.error("Error updating post:", error);
            alert("Error updating post.");
        }
    };

    const clearFilters = () => {
        setFilterDept("");
        setFilterSender("");
        setDateStart("");
        setDateEnd("");
    };

    if (!user && loading) return <div className="flex justify-center p-10"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div></div>;

    return (
        <div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column - Main Content */}
                <div className="lg:col-span-2 space-y-8">
                    {/* Welcome & Quick Actions Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Welcome Card */}
                        <div className="md:col-span-2 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white shadow-lg">
                            <h2 className="text-2xl font-bold">Welcome back, {user?.name}!</h2>
                            <p className="opacity-90 mt-2">Department: <span className="font-semibold">{user?.department}</span></p>
                            <p className="mt-4 text-sm opacity-75">Check out the latest updates from your team below.</p>
                        </div>

                        {/* Quick Actions */}
                        <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm flex flex-col justify-center">
                            <h3 className="text-gray-500 text-sm font-semibold uppercase tracking-wider mb-4">Quick Actions</h3>
                            <div className="space-y-3">
                                <Link to="/create-post" className="block w-full text-center py-2.5 px-4 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm">
                                    Create New Post
                                </Link>
                                <Link to="/profile" className="block w-full text-center py-2.5 px-4 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors">
                                    View My Profile
                                </Link>
                            </div>
                        </div>
                    </div>

                    {/* Filter Section */}
                    <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 mb-8">
                        <div className="flex items-center space-x-2 mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                            </svg>
                            <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider">Search & Filter</h4>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                            {/* Filter Department */}
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Department</label>
                                <select
                                    value={filterDept}
                                    onChange={(e) => setFilterDept(e.target.value)}
                                    className="block w-full bg-gray-50 border-gray-200 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2.5 border transition-all"
                                >
                                    <option value="">All Departments</option>
                                    {[...new Set(users.map(u => u.department).filter(Boolean))].map(dept => (
                                        <option key={dept} value={dept}>{dept}</option>
                                    ))}
                                </select>
                            </div>
                            {/* Filter Sender */}
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Sender</label>
                                <select
                                    value={filterSender}
                                    onChange={(e) => setFilterSender(e.target.value)}
                                    className="block w-full bg-gray-50 border-gray-200 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2.5 border transition-all"
                                >
                                    <option value="">All Senders</option>
                                    {users.map(u => (
                                        <option key={u.id} value={u.id}>{u.name}</option>
                                    ))}
                                </select>
                            </div>
                            {/* Date Range Start */}
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">From Date</label>
                                <input
                                    type="date"
                                    value={dateStart}
                                    onChange={(e) => setDateStart(e.target.value)}
                                    className="block w-full bg-gray-50 border-gray-200 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2.5 border transition-all"
                                />
                            </div>
                            {/* Date Range End & Action */}
                            <div className="flex space-x-2">
                                <div className="flex-1">
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">To Date</label>
                                    <input
                                        type="date"
                                        value={dateEnd}
                                        onChange={(e) => setDateEnd(e.target.value)}
                                        className="block w-full bg-gray-50 border-gray-200 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2.5 border transition-all"
                                    />
                                </div>
                                <button
                                    onClick={clearFilters}
                                    className="self-end p-2.5 border border-gray-200 rounded-lg shadow-sm text-gray-500 bg-gray-50 hover:bg-white hover:text-red-600 transition-all focus:outline-none"
                                    title="Clear all filters"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Posts Feed */}
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Shoutouts</h3>
                    <div className="space-y-6">
                        {loading ? (
                            <div className="flex justify-center p-10"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div></div>
                        ) : posts.length === 0 ? (
                            <div className="text-center py-10 bg-white rounded-xl border border-dashed border-gray-300">
                                <p className="text-gray-500">No posts found matching criteria.</p>
                            </div>
                        ) : (
                            posts.map(p => (
                                <PostCard key={p.id} post={p} user={user} onDelete={handleDeletePost} onEdit={setEditingPost} />
                            ))
                        )}
                    </div>
                </div>

                {/* Right Column - Sidebar */}
                <div className="space-y-8">
                    {/* Leaderboard Widget */}
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                        <LeaderboardView />
                    </div>

                    {/* Analytics Widget */}
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                        <h3 className="text-lg font-bold text-gray-800 mb-4 px-2">Analytics Snapshot</h3>
                        <div className="overflow-hidden">
                            <AnalyticsView />
                        </div>
                    </div>
                </div>
            </div>

            {/* Edit Modal */}
            <EditPostModal
                isOpen={!!editingPost}
                onClose={() => setEditingPost(null)}
                onSave={handleUpdatePost}
                post={editingPost}
            />
        </div>
    );
}
