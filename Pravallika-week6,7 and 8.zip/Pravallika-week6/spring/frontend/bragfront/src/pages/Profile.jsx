import React, { useEffect, useState } from "react";

export default function Profile() {
    const [user, setUser] = useState(null);
    const [uploading, setUploading] = useState(false);

    useEffect(() => {
        // We could reuse the context, but let's fetch for now for simplicity
        const fetchUser = async () => {
            const token = localStorage.getItem('token');
            if (token) {
                const response = await fetch('/api/users/me', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (response.ok) {
                    const data = await response.json();
                    setUser(data);
                }
            }
        };
        fetchUser();
    }, []);

    const handleAvatarChange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);

        setUploading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch('/api/users/me/avatar', {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            if (res.ok) {
                const data = await res.json();
                setUser({ ...user, avatar_url: data.avatar_url });
            } else {
                alert("Failed to upload avatar.");
            }
        } catch (error) {
            console.error("Error uploading avatar:", error);
            alert("Error uploading avatar.");
        } finally {
            setUploading(false);
        }
    };

    if (!user) return <div className="p-8">Loading Profile...</div>;

    return (
        <div className="max-w-xl mx-auto">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="bg-gradient-to-r from-indigo-500 to-blue-500 h-32"></div>
                <div className="p-8 text-center -mt-16">
                    <div className="relative inline-block">
                        {user.avatar_url ? (
                            <img
                                src={user.avatar_url}
                                alt={user.name}
                                className="w-32 h-32 rounded-full border-4 border-white bg-white mx-auto shadow-md object-cover"
                            />
                        ) : (
                            <div className="w-32 h-32 rounded-full border-4 border-white bg-gray-200 mx-auto flex items-center justify-center text-4xl text-gray-500 font-bold shadow-md">
                                {user.name?.[0]?.toUpperCase()}
                            </div>
                        )}
                        <label className="absolute bottom-0 right-0 bg-indigo-600 p-2 rounded-full border-2 border-white text-white cursor-pointer hover:bg-indigo-700 transition-colors shadow-sm">
                            {uploading ? (
                                <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                            ) : (
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                            )}
                            <input type="file" className="hidden" accept="image/*" onChange={handleAvatarChange} disabled={uploading} />
                        </label>
                    </div>
                    <h2 className="mt-4 text-2xl font-bold text-gray-800">{user.name}</h2>
                    <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800 mt-2">
                        {user.department}
                    </div>

                    <div className="mt-6 border-t pt-6 text-left">
                        <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                            <div className="sm:col-span-1">
                                <dt className="text-sm font-medium text-gray-500">Email address</dt>
                                <dd className="mt-1 text-sm text-gray-900">{user.email}</dd>
                            </div>
                            <div className="sm:col-span-1">
                                <dt className="text-sm font-medium text-gray-500">Role</dt>
                                <dd className="mt-1 text-sm text-gray-900 capitalize">{user.role}</dd>
                            </div>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    );
}
