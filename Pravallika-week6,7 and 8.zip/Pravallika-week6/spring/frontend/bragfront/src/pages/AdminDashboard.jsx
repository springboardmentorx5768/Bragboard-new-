import React, { useState, useEffect } from 'react';
import AnalyticsView from '../components/AnalyticsView';
import ContentModerationView from '../components/ContentModerationView';
import ReportsView from '../components/ReportsView';
import LeaderboardView from '../components/LeaderboardView';

const AdminDashboard = () => {
    const [activeTab, setActiveTab] = useState('analytics');
    const [userRole, setUserRole] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Check if user is admin
        const checkAdminAccess = async () => {
            try {
                const response = await fetch('/api/users/me', {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                const data = await response.json();
                setUserRole(data.role);

                if (data.role !== 'admin') {
                    window.location.href = '/dashboard';
                }
            } catch (error) {
                console.error('Error checking admin access:', error);
                window.location.href = '/dashboard';
            } finally {
                setLoading(false);
            }
        };

        checkAdminAccess();
    }, []);

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
                    <p className="mt-4 text-gray-600">Loading admin dashboard...</p>
                </div>
            </div>
        );
    }

    if (userRole !== 'admin') {
        return null;
    }

    const tabs = [
        { id: 'analytics', label: 'Analytics', icon: '📊' },
        { id: 'moderation', label: 'Content Moderation', icon: '🛡️' },
        { id: 'reports', label: 'Reports', icon: '🚩' },
        { id: 'leaderboard', label: 'Leaderboard', icon: '🏆' }
    ];

    return (
        <div className="min-h-screen bg-gray-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
                    <p className="mt-2 text-gray-600">Manage and monitor BragBoard platform</p>
                </div>

                {/* Tabs */}
                <div className="bg-white rounded-lg shadow-sm mb-6">
                    <div className="border-b border-gray-200">
                        <nav className="flex -mb-px">
                            {tabs.map(tab => (
                                <button
                                    key={tab.id}
                                    onClick={() => setActiveTab(tab.id)}
                                    className={`
                                        flex-1 py-4 px-6 text-center border-b-2 font-medium text-sm
                                        transition-colors duration-200
                                        ${activeTab === tab.id
                                            ? 'border-indigo-500 text-indigo-600'
                                            : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                        }
                                    `}
                                >
                                    <span className="mr-2">{tab.icon}</span>
                                    {tab.label}
                                </button>
                            ))}
                        </nav>
                    </div>
                </div>

                {/* Tab Content */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                    {activeTab === 'analytics' && <AnalyticsView />}
                    {activeTab === 'moderation' && <ContentModerationView />}
                    {activeTab === 'reports' && <ReportsView />}
                    {activeTab === 'leaderboard' && <LeaderboardView />}
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
