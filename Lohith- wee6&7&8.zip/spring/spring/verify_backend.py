import sys
import os

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), 'backend'))

from backend.database import Base
from backend.models import User, Post, Reaction, UserRole
from backend.services.reaction_service import ReactionService
from backend.services.post_service import PostService
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Setup Test DB
SQLALCHEMY_DATABASE_URL = "sqlite:///./backend/test_verification.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def cleanup():
    if os.path.exists("./backend/test_verification.db"):
        os.remove("./backend/test_verification.db")

def test_reaction_flow():
    cleanup()
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    
    try:
        # 1. Create User
        user = User(name="Test User", email="test@example.com", password="pw", department="Engineering")
        db.add(user)
        db.commit()
        db.refresh(user)
        
        # 2. Create Post
        post = PostService.create_post(db, "Test Title", "Message", user.id)
        print(f"Post created: {post.id}")
        
        # 3. Toggle Like
        print("Toggling Like...")
        res = ReactionService.toggle_reaction(db, post.id, user.id, "like")
        print(f"Result: {res['status']}")
        assert res['status'] == 'added'
        
        counts = ReactionService.get_reaction_counts(db, post.id)
        print(f"Counts: {counts}")
        assert counts['like'] == 1
        
        # 4. Toggle Clap (should exist alongside Like)
        print("Toggling Clap...")
        res = ReactionService.toggle_reaction(db, post.id, user.id, "clap")
        print(f"Result: {res['status']}")
        assert res['status'] == 'added'
        
        counts = ReactionService.get_reaction_counts(db, post.id)
        print(f"Counts: {counts}")
        assert counts['like'] == 1
        assert counts['clap'] == 1
        
        # 5. Toggle Like Again (Remove)
        print("Toggling Like (Remove)...")
        res = ReactionService.toggle_reaction(db, post.id, user.id, "like")
        print(f"Result: {res['status']}")
        assert res['status'] == 'removed'
        
        counts = ReactionService.get_reaction_counts(db, post.id)
        print(f"Counts: {counts}")
        assert 'like' not in counts or counts['like'] == 0
        assert counts['clap'] == 1
        
        # 6. Check User Reactions
        user_reactions = ReactionService.get_user_reactions(db, post.id, user.id)
        print(f"User Reactions: {user_reactions}")
        assert "clap" in user_reactions
        assert "like" not in user_reactions
        
        print("\n✅ Verification Successful!")
        
    except Exception as e:
        print(f"\n❌ Verification Failed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()
        cleanup()

if __name__ == "__main__":
    test_reaction_flow()
