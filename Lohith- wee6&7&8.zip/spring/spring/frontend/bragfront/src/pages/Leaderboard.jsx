import React, { useEffect, useState } from 'react';

export default function Leaderboard() {
    const [data, setData] = useState({ top_contributors: [], most_appreciated: [] });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            const token = localStorage.getItem('token');
            try {
                const res = await fetch('/api/users/leaderboard', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (res.ok) {
                    setData(await res.json());
                }
            } catch (error) {
                console.error("Error fetching leaderboard:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    if (loading) return <div className="flex justify-center p-10"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div></div>;

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
            <div className="text-center mb-12">
                <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600 mb-2">
                    BragBoard Hall of Fame
                </h1>
                <p className="text-gray-500 text-lg">Celebrating our top contributors and most appreciated stars!</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Top Contributors Card */}
                <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden relative">
                    <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 to-blue-500"></div>
                    <div className="p-8">
                        <div className="flex items-center space-x-3 mb-6">
                            <span className="text-3xl">🚀</span>
                            <h2 className="text-2xl font-bold text-gray-800">Top Contributors</h2>
                        </div>
                        <div className="space-y-4">
                            {data.top_contributors.map((user, index) => (
                                <div key={index} className="flex items-center justify-between p-4 rounded-xl bg-gray-50 hover:bg-indigo-50 transition-colors border border-gray-100">
                                    <div className="flex items-center space-x-4">
                                        <div className={`w-8 h-8 flex items-center justify-center rounded-full font-bold ${index === 0 ? 'bg-yellow-100 text-yellow-600 shadow-sm' :
                                                index === 1 ? 'bg-gray-200 text-gray-600' :
                                                    index === 2 ? 'bg-orange-100 text-orange-600' : 'bg-white text-gray-400 border border-gray-200'
                                            }`}>
                                            {index + 1}
                                        </div>
                                        <span className={`font-medium ${index < 3 ? 'text-gray-900 text-lg' : 'text-gray-600'}`}>{user.name}</span>
                                    </div>
                                    <span className="font-bold text-indigo-600">{user.count} posts</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Most Appreciated Card */}
                <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden relative">
                    <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-purple-500 to-pink-500"></div>
                    <div className="p-8">
                        <div className="flex items-center space-x-3 mb-6">
                            <span className="text-3xl">⭐</span>
                            <h2 className="text-2xl font-bold text-gray-800">Most Appreciated</h2>
                        </div>
                        <div className="space-y-4">
                            {data.most_appreciated.map((user, index) => (
                                <div key={index} className="flex items-center justify-between p-4 rounded-xl bg-gray-50 hover:bg-purple-50 transition-colors border border-gray-100">
                                    <div className="flex items-center space-x-4">
                                        <div className={`w-8 h-8 flex items-center justify-center rounded-full font-bold ${index === 0 ? 'bg-yellow-100 text-yellow-600 shadow-sm' :
                                                index === 1 ? 'bg-gray-200 text-gray-600' :
                                                    index === 2 ? 'bg-orange-100 text-orange-600' : 'bg-white text-gray-400 border border-gray-200'
                                            }`}>
                                            {index + 1}
                                        </div>
                                        <span className={`font-medium ${index < 3 ? 'text-gray-900 text-lg' : 'text-gray-600'}`}>{user.name}</span>
                                    </div>
                                    <div className="text-right">
                                        <span className="font-bold text-purple-600 block">{user.count}</span>
                                        <span className="text-xs text-purple-400 font-medium uppercase tracking-wide">Received</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
