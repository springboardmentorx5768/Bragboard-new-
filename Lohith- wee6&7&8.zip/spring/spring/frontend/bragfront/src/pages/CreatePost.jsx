import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function CreatePost() {
    const [title, setTitle] = useState("");
    const [message, setMessage] = useState("");
    const [image, setImage] = useState(null);
    const [preview, setPreview] = useState(null);
    const [submitting, setSubmitting] = useState(false);

    // Recipient Tagging
    const [users, setUsers] = useState([]);
    const [selectedRecipients, setSelectedRecipients] = useState([]); // Array of IDs

    const navigate = useNavigate();

    React.useEffect(() => {
        const fetchUsers = async () => {
            const token = localStorage.getItem('token');
            try {
                const res = await fetch('/api/users/', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (res.ok) {
                    const data = await res.json();
                    setUsers(data);
                }
            } catch (err) {
                console.error("Failed to fetch users", err);
            }
        };
        fetchUsers();
    }, []);

    function onImageChange(e) {
        const f = e.target.files[0];
        setImage(f);
        if (f) setPreview(URL.createObjectURL(f));
        else setPreview(null);
    }

    async function onSubmit(e) {
        e.preventDefault();
        setSubmitting(true);

        // Form Data for file upload
        const formData = new FormData();
        formData.append("title", title);
        formData.append("message", message);
        formData.append("recipient_ids", JSON.stringify(selectedRecipients));
        if (image) formData.append("image", image);

        const token = localStorage.getItem('token');

        try {
            const res = await fetch('/api/posts/', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            if (res.ok) {
                alert("Post created successfully!");
                navigate('/dashboard');
            } else {
                alert("Failed to create post. Please try again.");
            }
        } catch (e) {
            console.error(e);
            alert("Network error.");
        } finally {
            setSubmitting(false);
        }
    }

    return (
        <div className="max-w-2xl mx-auto">
            <div className="bg-white p-6 sm:p-8 rounded-xl shadow-sm border border-gray-100">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Create a Shoutout</h2>
                <form onSubmit={onSubmit} className="space-y-6">

                    {/* Title */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                        <input
                            required
                            value={title}
                            onChange={e => setTitle(e.target.value)}
                            className="block w-full border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-3 border text-gray-900"
                            placeholder="Ex: Great Job on the deployment!"
                        />
                    </div>

                    {/* Recipients */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tag Recipients (Optional)</label>
                        <select
                            multiple
                            value={selectedRecipients}
                            onChange={e => {
                                const options = [...e.target.selectedOptions];
                                const values = options.map(option => parseInt(option.value));
                                setSelectedRecipients(values);
                            }}
                            className="block w-full border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-3 border text-gray-900 h-32"
                        >
                            {users.map(u => (
                                <option key={u.id} value={u.id}>
                                    {u.name} ({u.department || 'No Dept'})
                                </option>
                            ))}
                        </select>
                        <p className="mt-1 text-xs text-gray-500">Hold Ctrl (Windows) or Cmd (Mac) to select multiple.</p>
                    </div>

                    {/* Message */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                        <textarea
                            required
                            value={message}
                            onChange={e => setMessage(e.target.value)}
                            className="block w-full border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-3 border text-gray-900"
                            rows="5"
                            placeholder="What did they achieve?"
                        ></textarea>
                    </div>

                    {/* Image Upload */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Attach an Image (Optional)</label>
                        <div className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg ${preview ? 'border-solid border-gray-200' : ''}`}>
                            <div className="space-y-1 text-center">
                                {preview ? (
                                    <div className="relative">
                                        <img src={preview} alt="Preview" className="mx-auto h-48 object-cover rounded-md" />
                                        <button
                                            type="button"
                                            onClick={() => { setImage(null); setPreview(null) }}
                                            className="text-xs text-red-500 underline mt-2"
                                        >Remove Image</button>
                                    </div>
                                ) : (
                                    <>
                                        <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                        <div className="flex text-sm text-gray-600 justify-center">
                                            <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none">
                                                <span>Upload a file</span>
                                                <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" onChange={onImageChange} />
                                            </label>
                                            <p className="pl-1">or drag and drop</p>
                                        </div>
                                        <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="flex items-center space-x-4 pt-4">
                        <button
                            type="submit"
                            disabled={submitting}
                            className="flex-1 flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
                        >
                            {submitting ? "Posting..." : "Create Post"}
                        </button>
                        <button
                            type="button"
                            onClick={() => { setTitle(""); setMessage(""); setImage(null); setPreview(null); setSelectedRecipients([]); }}
                            className="flex-1 py-3 px-4 border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                        >
                            Reset
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
