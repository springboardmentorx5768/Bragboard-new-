import React, { useEffect, useState } from "react";

export default function Profile() {
    const [user, setUser] = useState(null);

    useEffect(() => {
        // We could reuse the context, but let's fetch for now for simplicity
        const fetchUser = async () => {
            const token = localStorage.getItem('token');
            if (token) {
                const response = await fetch('/api/users/me', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (response.ok) {
                    const data = await response.json();
                    setUser(data);
                }
            }
        };
        fetchUser();
    }, []);

    if (!user) return <div className="p-8">Loading Profile...</div>;

    return (
        <div className="max-w-xl mx-auto">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="bg-gradient-to-r from-indigo-500 to-blue-500 h-32"></div>
                <div className="p-8 text-center -mt-16">
                    <div className="w-32 h-32 rounded-full border-4 border-white bg-gray-200 mx-auto flex items-center justify-center text-4xl text-gray-500 font-bold shadow-md">
                        {user.name?.[0]?.toUpperCase()}
                    </div>
                    <h2 className="mt-4 text-2xl font-bold text-gray-800">{user.name}</h2>
                    <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800 mt-2">
                        {user.department}
                    </div>

                    <div className="mt-6 border-t pt-6 text-left">
                        <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                            <div className="sm:col-span-1">
                                <dt className="text-sm font-medium text-gray-500">Email address</dt>
                                <dd className="mt-1 text-sm text-gray-900">{user.email}</dd>
                            </div>
                            <div className="sm:col-span-1">
                                <dt className="text-sm font-medium text-gray-500">Role</dt>
                                <dd className="mt-1 text-sm text-gray-900 capitalize">{user.role}</dd>
                            </div>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    );
}
