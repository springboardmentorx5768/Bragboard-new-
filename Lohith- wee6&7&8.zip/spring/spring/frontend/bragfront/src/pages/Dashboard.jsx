import React, { useEffect, useState } from "react";
import PostCard from "../components/PostCard";
import EditPostModal from "../components/EditPostModal";
import FilterModal from "../components/FilterModal";
import { Link } from "react-router-dom";

export default function Dashboard() {
    const [user, setUser] = useState(null);
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [editingPost, setEditingPost] = useState(null);
    const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
    const [filters, setFilters] = useState({ sender: '', department: '', date: '' });

    useEffect(() => {
        // Placeholder posts for initial paint before API
        const placeholderPosts = [
            {
                id: 1,
                sender_name: "Anil",
                sender_department: "CSE",
                title: "Great teamwork!",
                message: "Thanks to everyone who helped with the sprint delivery.",
                recipients: [{ id: 2, name: "Meena" }, { id: 3, name: "Raju" }],
                image_url: null,
                reaction_count: 5,
                user_has_reacted: true,
                created_at: new Date().toISOString()
            }
        ];

        const fetchData = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                window.location.href = '/login';
                return;
            }

            try {
                // Fetch User
                const userRes = await fetch('/api/users/me', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (userRes.ok) {
                    const userData = await userRes.json();
                    setUser(userData);
                }

                // Build Query String
                const queryParams = new URLSearchParams();
                if (filters.sender) queryParams.append('sender', filters.sender);
                if (filters.department) queryParams.append('department', filters.department);
                if (filters.date) queryParams.append('date', filters.date);

                // Fetch Posts
                const postsRes = await fetch(`/api/posts/?${queryParams.toString()}`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (postsRes.ok) {
                    const postsData = await postsRes.json();
                    setPosts(postsData);
                } else {
                    setPosts(placeholderPosts); // Fallback for Demo
                }

            } catch (error) {
                console.error("Failed to fetch dashboard data", error);
                setPosts(placeholderPosts);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [filters]); // Re-fetch when filters change

    const handleDeletePost = async (postId) => {
        if (!user) return;
        const post = posts.find(p => p.id === postId);
        if (!post) return;

        const isOwner = post.sender_id === user.id;
        const isAdmin = user.role === 'admin';

        if (!isOwner && !isAdmin) {
            alert("You are not authorized to delete this post.");
            return;
        }

        const endpoint = isOwner ? `/api/posts/${postId}` : `/api/admin/posts/${postId}`;

        const token = localStorage.getItem('token');
        try {
            const res = await fetch(endpoint, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (res.ok) {
                setPosts(posts.filter(p => p.id !== postId));
            } else {
                console.error("Failed to delete post");
                alert("Failed to delete post.");
            }
        } catch (error) {
            console.error("Error deleting post:", error);
            alert("Error deleting post.");
        }
    };

    const handleUpdatePost = async (postId, title, message) => {
        const token = localStorage.getItem('token');
        const formData = new FormData();
        formData.append('title', title);
        formData.append('message', message);

        try {
            const res = await fetch(`/api/posts/${postId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            if (res.ok) {
                await res.json();
                // Update local state
                setPosts(posts.map(p => p.id === postId ? { ...p, title, message } : p));
                setEditingPost(null);
            } else {
                console.error("Failed to update post");
                alert("Failed to update post.");
            }
        } catch (error) {
            console.error("Error updating post:", error);
            alert("Error updating post.");
        }
    };

    if (loading) return <div className="flex justify-center p-10"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div></div>;

    return (
        <div>
            {/* Welcome & Quick Actions Grid */}
            <div className="mb-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Welcome Card */}
                <div className="md:col-span-2 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white shadow-lg relative">
                    <div className="flex justify-between items-start">
                        <h2 className="text-2xl font-bold">Welcome back, {user?.name}!</h2>
                        <button
                            onClick={() => setIsFilterModalOpen(true)}
                            className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors backdrop-blur-sm"
                            title="Filter Posts"
                        >
                            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                            </svg>
                        </button>
                    </div>
                    <p className="opacity-90 mt-2">Department: <span className="font-semibold">{user?.department}</span></p>
                    <p className="mt-4 text-sm opacity-75">Check out the latest updates from your team below.</p>
                </div>

                {/* Quick Actions */}
                <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm flex flex-col justify-center">
                    <h3 className="text-gray-500 text-sm font-semibold uppercase tracking-wider mb-4">Quick Actions</h3>
                    <div className="space-y-3">
                        <Link to="/create-post" className="block w-full text-center py-2.5 px-4 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm">
                            Create New Post
                        </Link>
                        <Link to="/profile" className="block w-full text-center py-2.5 px-4 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors">
                            View My Profile
                        </Link>
                    </div>
                </div>
            </div>

            {/* Posts Feed */}
            <h3 className="text-xl font-bold text-gray-800 mb-4">Recent Shoutouts</h3>
            <div className="space-y-6">
                {posts.length === 0 ? (
                    <div className="text-center py-10 bg-white rounded-xl border border-dashed border-gray-300">
                        <p className="text-gray-500">No posts visible for your department yet.</p>
                    </div>
                ) : (
                    posts.map(p => (
                        <PostCard
                            key={p.id}
                            post={p}
                            user={user}
                            isAdmin={user?.role === 'admin'}
                            onDelete={handleDeletePost}
                            onEdit={setEditingPost}
                        />
                    ))
                )}
            </div>

            <EditPostModal
                isOpen={!!editingPost}
                onClose={() => setEditingPost(null)}
                onSave={handleUpdatePost}
                post={editingPost}
            />

            <FilterModal
                isOpen={isFilterModalOpen}
                onClose={() => setIsFilterModalOpen(false)}
                onApply={(newFilters) => {
                    setFilters(newFilters);
                    setIsFilterModalOpen(false);
                }}
                currentFilters={filters}
            />
        </div>
    );
}
