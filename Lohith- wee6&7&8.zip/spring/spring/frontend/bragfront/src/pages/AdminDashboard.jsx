import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';

export default function AdminDashboard() {
    const [stats, setStats] = useState(null);
    const [logs, setLogs] = useState([]);
    const [reports, setReports] = useState([]);
    const [loading, setLoading] = useState(true);
    const [user, setUser] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            const token = localStorage.getItem('token');
            if (!token) return;

            try {
                // 1. Check User Role first (redundant if protected logic is good, but safe)
                const userRes = await fetch('/api/users/me', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (!userRes.ok) throw new Error("Failed to fetch user");
                const userData = await userRes.json();
                setUser(userData);

                if (userData.role !== 'admin') {
                    return; // Will redirect in render
                }

                // 2. Fetch Admin Data
                const [statsRes, logsRes, reportsRes] = await Promise.all([
                    fetch('/api/admin/stats', { headers: { 'Authorization': `Bearer ${token}` } }),
                    fetch('/api/admin/logs', { headers: { 'Authorization': `Bearer ${token}` } }),
                    fetch('/api/admin/reports', { headers: { 'Authorization': `Bearer ${token}` } })
                ]);

                if (statsRes.ok) setStats(await statsRes.json());
                if (logsRes.ok) setLogs(await logsRes.json());
                if (reportsRes.ok) setReports(await reportsRes.json());

            } catch (error) {
                console.error("Error fetching admin data:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    const handleResolveReport = async (reportId, status) => {
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/admin/reports/${reportId}/resolve?status_update=${status}`, {
                method: 'PUT',
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (res.ok) {
                // Update local state
                setReports(reports.map(r => r.id === reportId ? { ...r, status: status } : r));
            } else {
                alert("Failed to update report");
            }
        } catch (error) {
            console.error("Error resolving report:", error);
        }
    };

    const handleExport = async (type) => {
        const token = localStorage.getItem('token');
        try {
            const res = await fetch(`/api/admin/export/${type}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (res.ok) {
                const blob = await res.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${type}.csv`;
                document.body.appendChild(a);
                a.click();
                a.remove();
            } else {
                alert("Export failed");
            }
        } catch (error) {
            console.error("Export error:", error);
        }
    };

    if (loading) return <div className="flex justify-center p-10"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div></div>;

    if (user && user.role !== 'admin') {
        return <Navigate to="/dashboard" replace />;
    }

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>

            {/* Stats Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2 flex justify-end">
                    <button
                        onClick={() => handleExport('stats')}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-green-700 flex items-center gap-2"
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                        Export Stats CSV
                    </button>
                </div>
                {/* Top Contributors */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h2 className="text-xl font-semibold mb-4 text-gray-800">Top Contributors</h2>
                    <div className="space-y-3">
                        {stats?.top_contributors?.map((u, i) => (
                            <div key={i} className="flex justify-between items-center border-b border-gray-50 pb-2 last:border-0">
                                <span className="font-medium text-gray-700">{u.name}</span>
                                <span className="bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full text-xs font-bold">{u.count} posts</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Most Tagged */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                    <h2 className="text-xl font-semibold mb-4 text-gray-800">Most Appreciation Received</h2>
                    <div className="space-y-3">
                        {stats?.most_tagged_users?.map((u, i) => (
                            <div key={i} className="flex justify-between items-center border-b border-gray-50 pb-2 last:border-0">
                                <span className="font-medium text-gray-700">{u.name}</span>
                                <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-bold">{u.count} shoutouts</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Reports Section */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 overflow-hidden">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-semibold text-gray-800">Content Reports</h2>
                    <button
                        onClick={() => handleExport('reports')}
                        className="bg-indigo-50 text-indigo-700 px-3 py-1.5 rounded-lg text-sm font-semibold hover:bg-indigo-100 border border-indigo-200 transition-colors"
                    >
                        Export CSV
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reason</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Post ID</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {reports.length === 0 ? (
                                <tr>
                                    <td colSpan="5" className="px-6 py-4 text-center text-sm text-gray-500">No reports found.</td>
                                </tr>
                            ) : (
                                reports.map((report) => (
                                    <tr key={report.id}>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(report.created_at).toLocaleDateString()}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{report.reason}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{report.post_id}</td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${report.status === 'resolved' ? 'bg-green-100 text-green-800' :
                                                report.status === 'dismissed' ? 'bg-gray-100 text-gray-800' :
                                                    'bg-yellow-100 text-yellow-800'
                                                }`}>
                                                {report.status || 'pending'}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                                            {(!report.status || report.status === 'pending') && (
                                                <>
                                                    <button onClick={() => handleResolveReport(report.id, 'resolved')} className="text-green-600 hover:text-green-900">Resolve</button>
                                                    <button onClick={() => handleResolveReport(report.id, 'dismissed')} className="text-gray-600 hover:text-gray-900">Dismiss</button>
                                                </>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Logs Section */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 overflow-hidden">
                <h2 className="text-xl font-semibold mb-4 text-gray-800">Admin Activity Log</h2>
                <div className="overflow-x-auto max-h-96 overflow-y-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50 sticky top-0">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Target</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {logs.map((log) => (
                                <tr key={log.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {new Date(log.timestamp).toLocaleString()}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                                        {log.action}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {log.target_type} #{log.target_id}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
