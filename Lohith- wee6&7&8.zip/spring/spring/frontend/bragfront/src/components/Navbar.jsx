import React from "react";
import { Link } from "react-router-dom";

export default function Navbar({ onToggleSidebar, user }) {
    const handleLogout = () => {
        localStorage.removeItem('token');
        window.location.href = '/login';
    }

    return (
        <header className="bg-white border-b shadow-sm sticky top-0 z-30">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between h-16">
                    <div className="flex items-center">
                        <button
                            className="sm:hidden p-2 rounded-md hover:bg-gray-100 mr-2"
                            onClick={onToggleSidebar}
                            aria-label="Toggle sidebar"
                        >
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                            </svg>
                        </button>
                        <Link to="/" className="flex-shrink-0 flex items-center">
                            <span className="text-2xl font-bold text-indigo-600 tracking-tight">BragBoard</span>
                        </Link>
                        <div className="hidden sm:flex items-center space-x-6 ml-6">
                            <Link to="/leaderboard" className="text-sm font-medium text-gray-500 hover:text-indigo-600 transition-colors">
                                Leaderboard
                            </Link>
                            {user?.role === 'admin' && (
                                <Link to="/admin" className="text-sm font-medium text-gray-500 hover:text-indigo-600 transition-colors">
                                    Admin Dashboard
                                </Link>
                            )}
                        </div>
                    </div>

                    <div className="flex items-center space-x-4">
                        <div className="text-sm text-gray-700 hidden sm:block">
                            <span className="text-gray-500 mr-1">Welcome,</span>
                            <span className="font-medium">{user?.name}</span>
                        </div>
                        <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-semibold border border-indigo-200">
                                {(user?.name || "U")[0].toUpperCase()}
                            </div>
                            <button
                                onClick={handleLogout}
                                className="text-sm text-red-600 hover:text-red-800 font-medium"
                            >
                                Logout
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
}
