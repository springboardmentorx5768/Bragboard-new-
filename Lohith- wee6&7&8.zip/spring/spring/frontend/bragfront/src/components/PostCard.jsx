import React from "react";

export default function PostCard({ post, user, onDelete, onEdit, isAdmin }) {
    // Format date nicely
    const formatDate = (dateString) => {
        if (!dateString) return '';
        try {
            return new Date(dateString).toLocaleDateString(undefined, {
                month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            });
        } catch (e) { return dateString }
    };

    const isOwner = user && post.sender_id === user.id;

    // Reaction State
    const [reactionCounts, setReactionCounts] = React.useState(post.reaction_counts || {});
    const [userReactions, setUserReactions] = React.useState(post.user_reactions || []);
    const [reacting, setReacting] = React.useState(false);

    const reactionTypes = [
        { type: 'like', icon: '👍', label: 'Like' },
        { type: 'clap', icon: '👏', label: 'Clap' },
        { type: 'star', icon: '⭐', label: 'Star' }
    ];

    // Comment State
    const [comments, setComments] = React.useState([]);
    const [showComments, setShowComments] = React.useState(false);
    const [newComment, setNewComment] = React.useState("");
    const [loadingComments, setLoadingComments] = React.useState(false);

    const fetchComments = async () => {
        setLoadingComments(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`http://localhost:8000/api/posts/${post.id}/comments`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (res.ok) {
                const data = await res.json();
                setComments(data);
            }
        } catch (err) {
            console.error(err);
        } finally {
            setLoadingComments(false);
        }
    };

    const handleCommentSubmit = async (e) => {
        e.preventDefault();
        if (!newComment.trim()) return;
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`http://localhost:8000/api/posts/${post.id}/comments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ content: newComment })
            });
            if (res.ok) {
                const comment = await res.json();
                setComments([...comments, comment]);
                setNewComment("");
            }
        } catch (err) {
            console.error(err);
        }
    };

    const toggleComments = () => {
        if (!showComments) {
            fetchComments();
        }
        setShowComments(!showComments);
    };

    const handleReaction = async (type) => {
        if (reacting) return;
        setReacting(true);

        const previousCounts = { ...reactionCounts };
        const previousUserReactions = [...userReactions];

        // Optimistic Update
        const hasReacted = userReactions.includes(type);
        let newCounts = { ...reactionCounts };
        let newUserReactions = [...userReactions];

        if (hasReacted) {
            newUserReactions = newUserReactions.filter(r => r !== type);
            newCounts[type] = Math.max(0, (newCounts[type] || 0) - 1);
        } else {
            newUserReactions.push(type);
            newCounts[type] = (newCounts[type] || 0) + 1;
        }

        setReactionCounts(newCounts);
        setUserReactions(newUserReactions);

        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/posts/${post.id}/react`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ reaction_type: type })
            });

            if (res.ok) {
                const data = await res.json();
                setReactionCounts(data.reaction_counts);
                setUserReactions(data.user_reactions);
            } else {
                // Revert
                setReactionCounts(previousCounts);
                setUserReactions(previousUserReactions);
                console.error("Failed to react");
            }
        } catch (error) {
            setReactionCounts(previousCounts);
            setUserReactions(previousUserReactions);
            console.error("Error reacting:", error);
        } finally {
            setReacting(false);
        }
    };

    const handleDeleteClick = () => {
        if (window.confirm("Are you sure you want to delete this post?")) {
            onDelete(post.id);
        }
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-md transition-shadow duration-200 group">
            <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg shadow-sm">
                        {post.sender_name?.[0]?.toUpperCase()}
                    </div>
                </div>
                <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm font-semibold text-gray-900 truncate">
                                {post.sender_name}
                                {post.recipients && post.recipients.length > 0 && (
                                    <span className="font-normal text-gray-500">
                                        {' '}with{' '}
                                        {post.recipients.map((r, i) => (
                                            <span key={r.id}>
                                                {i > 0 && ", "}
                                                <span className="text-indigo-600 font-medium">@{r.name}</span>
                                            </span>
                                        ))}
                                    </span>
                                )}
                            </p>
                            <p className="text-xs text-indigo-600 font-medium">{post.sender_department}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                            <span className="text-xs text-gray-400 whitespace-nowrap mr-2">{formatDate(post.created_at)}</span>

                            {/* Reaction Buttons */}
                            {reactionTypes.map((rt) => {
                                const isActive = userReactions.includes(rt.type);
                                const count = reactionCounts[rt.type] || 0;
                                return (
                                    <button
                                        key={rt.type}
                                        onClick={() => handleReaction(rt.type)}
                                        className={`flex items-center space-x-1 px-2 py-1 rounded-full transition-all text-sm border ${isActive
                                            ? 'bg-indigo-50 border-indigo-200 text-indigo-700 shadow-sm'
                                            : 'bg-gray-50 border-transparent text-gray-500 hover:bg-gray-100'
                                            }`}
                                        title={rt.label}
                                    >
                                        <span>{rt.icon}</span>
                                        {count > 0 && <span className="font-medium text-xs">{count}</span>}
                                    </button>
                                );
                            })}

                            <button
                                onClick={toggleComments}
                                className="flex items-center space-x-1 px-2 py-1 rounded-full bg-gray-50 text-gray-500 hover:bg-gray-100 transition-colors text-sm"
                                title="Comments"
                            >
                                <span>💬</span>
                                <span className="font-medium text-xs">{comments.length > 0 ? comments.length : ''}</span>
                            </button>

                            {isOwner && (
                                <button
                                    onClick={() => onEdit(post)}
                                    className="text-gray-400 hover:text-indigo-600 transition-colors p-1 rounded-full hover:bg-indigo-50"
                                    title="Edit Post"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                    </svg>
                                </button>
                            )}
                            {(isOwner || isAdmin) && (
                                <button
                                    onClick={handleDeleteClick}
                                    className="text-gray-400 hover:text-red-600 transition-colors p-1 rounded-full hover:bg-red-50"
                                    title="Delete Post"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                </button>
                            )}
                        </div>
                    </div>

                    <h3 className="mt-2 text-lg font-semibold text-gray-800 leading-snug">{post.title}</h3>
                    <p className="mt-2 text-gray-600 text-sm leading-relaxed">{post.message}</p>

                    {post.image_url && (
                        <div className="mt-4 rounded-lg overflow-hidden border border-gray-100">
                            <img
                                className="w-full h-auto object-cover max-h-96"
                                src={`http://localhost:8000${post.image_url}`}
                                alt="post attachment"
                                loading="lazy"
                            />
                        </div>
                    )}

                    {/* Comment Section */}
                    {showComments && (
                        <div className="mt-4 pt-4 border-t border-gray-100 w-full">
                            <div className="space-y-4 mb-4">
                                {loadingComments ? (
                                    <p className="text-center text-gray-500 text-sm">Loading comments...</p>
                                ) : comments.length === 0 ? (
                                    <p className="text-center text-gray-400 text-sm">No comments yet. Be the first!</p>
                                ) : (
                                    comments.map((comment) => (
                                        <div key={comment.id} className="flex space-x-3">
                                            <div className="flex-shrink-0">
                                                <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-bold text-xs">
                                                    {comment.user_name?.[0]?.toUpperCase()}
                                                </div>
                                            </div>
                                            <div className="flex-1 bg-gray-50 rounded-lg p-3 text-sm">
                                                <div className="flex justify-between items-baseline mb-1">
                                                    <span className="font-semibold text-gray-900">{comment.user_name}</span>
                                                    <span className="text-xs text-gray-500">{formatDate(comment.created_at)}</span>
                                                </div>
                                                <p className="text-gray-700">{comment.content}</p>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>

                            <form onSubmit={handleCommentSubmit} className="flex gap-2">
                                <input
                                    type="text"
                                    value={newComment}
                                    onChange={(e) => setNewComment(e.target.value)}
                                    placeholder="Write a comment..."
                                    className="flex-1 rounded-full border border-gray-300 px-4 py-2 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                                />
                                <button
                                    type="submit"
                                    disabled={!newComment.trim()}
                                    className="bg-indigo-600 text-white rounded-full px-4 py-2 text-sm font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                >
                                    Send
                                </button>
                            </form>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
