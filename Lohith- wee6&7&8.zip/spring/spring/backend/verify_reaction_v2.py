import time
from fastapi.testclient import TestClient
from main import app
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database import Base, get_db
import os
import json

# Use unique file for testing to avoid locking issues
db_file = f"test_react_v2_{int(time.time())}.db"
SQLALCHEMY_DATABASE_URL = f"sqlite:///./{db_file}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def verify_reaction_logic():
    print(f"Using DB: {db_file}")
    Base.metadata.create_all(bind=engine)
    
    try:
        # 1. Register User A (Owner)
        client.post("/api/register", json={
            "name": "User A",
            "email": "usera@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        token_a = client.post("/api/login", json={"email": "usera@example.com", "password": "password"}).json()["access_token"]
        headers_a = {"Authorization": f"Bearer {token_a}"}
        
        # 2. Register User B (Reactor) - Different Department
        client.post("/api/register", json={
            "name": "User B",
            "email": "userb@example.com",
            "password": "password",
            "department": "Sales", # Changed from IT to Sales
            "role": "employee"
        })
        token_b = client.post("/api/login", json={"email": "userb@example.com", "password": "password"}).json()["access_token"]
        headers_b = {"Authorization": f"Bearer {token_b}"}

        # 3. Create Post by A
        print("\n--- Testing Owner Constraint ---")
        create_res = client.post("/api/posts/", data={"title": "Test Post", "message": "Content"}, headers=headers_a)
        assert create_res.status_code == 200, f"Setup fail: {create_res.text}"
        post_id = create_res.json()["id"]
        
        # 4. User A tries to react (Should Fail)
        res_fail = client.post(f"/api/posts/{post_id}/react", json={"reaction_type": "like"}, headers=headers_a)
        if res_fail.status_code == 403:
            print("✅ Success: Owner cannot react to own post (403 Forbidden)")
        else:
            print(f"❌ Failed: Owner was able to react or wrong status code: {res_fail.status_code}")
            return

        # 5. User B reactions (Like)
        print("\n--- Testing Reaction Types ---")
        res_like = client.post(f"/api/posts/{post_id}/react", json={"reaction_type": "like"}, headers=headers_b)
        assert res_like.status_code == 200
        data = res_like.json()
        assert data["status"] == "added"
        assert data["reaction_counts"]["like"] == 1
        assert "like" in data["user_reactions"]
        print("✅ User B liked successfully")

        # 6. User B reactions (Clap) - Multiple types allowed? Logic says 'toggle', but model constraints might allow unique (post, user, type)
        # The schema uses UniqueConstraint per type, so yes.
        res_clap = client.post(f"/api/posts/{post_id}/react", json={"reaction_type": "clap"}, headers=headers_b)
        assert res_clap.status_code == 200
        data = res_clap.json()
        assert data["status"] == "added"
        assert data["reaction_counts"]["like"] == 1
        assert data["reaction_counts"]["clap"] == 1
        assert "like" in data["user_reactions"]
        assert "clap" in data["user_reactions"]
        print("✅ User B clapped successfully (Multi-reaction supported)")

        # 7. User B toggles Like off
        res_toggle = client.post(f"/api/posts/{post_id}/react", json={"reaction_type": "like"}, headers=headers_b)
        assert res_toggle.status_code == 200
        data = res_toggle.json()
        assert data["status"] == "removed"
        assert "like" not in data.get("reaction_counts", {}) # might returns empty if 0 or 0
        assert data["reaction_counts"].get("like", 0) == 0
        assert "like" not in data["user_reactions"]
        print("✅ User B toggled like off successfully")

        print("\n=== ALL VERIFICATION CHECKS PASSED ===")

    except Exception as e:
        print(f"❌ An error occurred: {e}")
    finally:
        engine.dispose()
        if os.path.exists(db_file):
            try:
                os.remove(db_file)
            except:
                pass

if __name__ == "__main__":
    verify_reaction_logic()
