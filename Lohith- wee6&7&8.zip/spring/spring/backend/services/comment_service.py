from sqlalchemy.orm import Session
from models import Comment, User

class CommentService:
    @staticmethod
    def create_comment(db: Session, shoutout_id: int, user_id: int, content: str):
        comment = Comment(shoutout_id=shoutout_id, user_id=user_id, content=content)
        db.add(comment)
        db.commit()
        db.refresh(comment)
        return comment

    @staticmethod
    def get_comments_for_post(db: Session, shoutout_id: int):
        return db.query(Comment).filter(Comment.shoutout_id == shoutout_id).order_by(Comment.created_at.asc()).all()
