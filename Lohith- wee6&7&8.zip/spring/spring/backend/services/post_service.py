from sqlalchemy.orm import Session
from sqlalchemy import desc
import models, schemas
import os
import shutil
from uuid import uuid4
from fastapi import UploadFile

UPLOAD_DIR = "uploads"

class PostService:
    @staticmethod
    def create_post(db: Session, title: str, message: str, user_id: int, image: UploadFile = None, recipient_ids: list[int] = None):
        image_url = None
        if image:
            os.makedirs(UPLOAD_DIR, exist_ok=True)
            filename = f"{uuid4()}_{image.filename}"
            path = os.path.join(UPLOAD_DIR, filename)
            with open(path, "wb") as buffer:
                shutil.copyfileobj(image.file, buffer)
            image_url = f"/uploads/{filename}"

        post = models.Post(
            title=title,
            message=message,
            image_url=image_url,
            sender_id=user_id
        )
        db.add(post)
        db.commit()
        db.refresh(post)

        if recipient_ids:
            for rid in recipient_ids:
                recipient = models.ShoutoutRecipient(post_id=post.id, recipient_id=rid)
                db.add(recipient)
            db.commit()

        return post

    @staticmethod
    def get_filtered_posts(db: Session, current_user_id: int, current_user_dept: str, sender_name: str = None, target_department: str = None, date_str: str = None):
        query = db.query(models.Post).join(models.User, models.Post.sender_id == models.User.id).outerjoin(models.ShoutoutRecipient, models.ShoutoutRecipient.post_id == models.Post.id)

        # Base Scope Logic
        # If a specific department is requested, we strictly filter by that.
        # If NOT, we use the default "My Department OR I am a recipient" logic (Home Feed behavior).
        if target_department:
            query = query.filter(models.User.department == target_department)
        else:
            query = query.filter(
                (models.User.department == current_user_dept) | 
                (models.ShoutoutRecipient.recipient_id == current_user_id)
            )

        # Additional Filters
        if sender_name:
            query = query.filter(models.User.name.ilike(f"%{sender_name}%"))
        
        if date_str:
            # Assumes generic SQL date casting; for SQLite/Postgres this usually works or use func.date()
            from sqlalchemy import func
            query = query.filter(func.date(models.Post.created_at) == date_str)

        posts = (
            query
            .order_by(models.Post.created_at.desc())
            .distinct()
            .all()
        )
        return posts

    @staticmethod
    def get_post(db: Session, post_id: int):
        return db.query(models.Post).filter(models.Post.id == post_id).first()

    @staticmethod
    def update_post(db: Session, post: models.Post, title: str = None, message: str = None):
        if title:
            post.title = title
        if message:
            post.message = message
        db.commit()
        db.refresh(post)
        return post

    @staticmethod
    def delete_post(db: Session, post: models.Post):
        if post.image_url:
            try:
                filename = post.image_url.split("/")[-1]
                file_path = os.path.join(UPLOAD_DIR, filename)
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception as e:
                print(f"Error deleting file: {e}")
        
        db.delete(post)
        db.commit()
