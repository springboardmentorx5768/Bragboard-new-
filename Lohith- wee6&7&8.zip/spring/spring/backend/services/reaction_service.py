from sqlalchemy.orm import Session
from sqlalchemy import and_, func
import models, schemas

class ReactionService:
    @staticmethod
    def toggle_reaction(db: Session, post_id: int, user_id: int, reaction_type: str = "like"):
        # Check if reaction of this type exists
        existing_reaction = db.query(models.Reaction).filter(
            and_(
                models.Reaction.post_id == post_id, 
                models.Reaction.user_id == user_id,
                models.Reaction.reaction_type == reaction_type
            )
        ).first()

        if existing_reaction:
            # If exists, remove it (toggle off)
            db.delete(existing_reaction)
            db.commit()
            return {"status": "removed"}
        else:
            # If not exists, add it (toggle on)
            new_reaction = models.Reaction(
                post_id=post_id,
                user_id=user_id,
                reaction_type=reaction_type
            )
            db.add(new_reaction)
            db.commit()
            db.refresh(new_reaction)
            return {"status": "added", "reaction": new_reaction}

    @staticmethod
    def get_reactions_for_post(db: Session, post_id: int):
        return db.query(models.Reaction).filter(models.Reaction.post_id == post_id).all()

    @staticmethod
    def get_reaction_counts(db: Session, post_id: int) -> dict:
        results = db.query(
            models.Reaction.reaction_type, 
            func.count(models.Reaction.reaction_type)
        ).filter(
            models.Reaction.post_id == post_id
        ).group_by(
            models.Reaction.reaction_type
        ).all()
        
        # Convert to dict, e.g., {'like': 5, 'clap': 2}
        return {r[0]: r[1] for r in results}

    @staticmethod
    def get_user_reactions(db: Session, post_id: int, user_id: int) -> list:
        results = db.query(models.Reaction.reaction_type).filter(
            and_(models.Reaction.post_id == post_id, models.Reaction.user_id == user_id)
        ).all()
        # Returns list of types e.g. ['like', 'star']
        return [r[0] for r in results]
