from sqlalchemy.orm import Session
import models

class UserService:
    @staticmethod
    def get_all_users(db: Session):
        return db.query(models.User).all()

    @staticmethod
    def get_users_by_ids(db: Session, user_ids: list[int]):
        return db.query(models.User).filter(models.User.id.in_(user_ids)).all()
