from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime
from models import UserRole, ReactionType

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    department: Optional[str] = None
    role: UserRole = UserRole.employee

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None

class UserResponse(BaseModel):
    id: int
    name: str
    email: EmailStr
    department: str
    role: UserRole
    
    class Config:
        from_attributes = True

class ReactionCreate(BaseModel):
    reaction_type: ReactionType = ReactionType.like

class ReactionResponse(BaseModel):
    id: int
    post_id: int
    user_id: int
    reaction_type: str
    
    class Config:
        from_attributes = True

class UserBasic(BaseModel):
    id: int
    name: str
    email: str
    department: Optional[str]

    class Config:
        from_attributes = True

class PostResponse(BaseModel):
    id: int
    title: str
    message: str
    image_url: Optional[str]
    created_at: datetime
    sender_id: int
    sender_name: str
    sender_department: Optional[str]
    reaction_counts: dict[str, int] = {}
    user_reactions: list[str] = []
    recipients: list[UserBasic] = []
    
    class Config:
        from_attributes = True


class CommentCreate(BaseModel):
    content: str

class CommentResponse(BaseModel):
    id: int
    shoutout_id: int
    user_id: int
    content: str
    created_at: datetime
    user_name: str  # To verify whom the comment is from
    
    class Config:
        from_attributes = True
    class Config:
        from_attributes = True

class AdminLogResponse(BaseModel):
    id: int
    admin_id: int
    action: str
    target_id: int
    target_type: str
    timestamp: datetime
    
    class Config:
        from_attributes = True

class ReportCreate(BaseModel):
    reason: str

class ReportResponse(BaseModel):
    id: int
    reporter_id: int
    post_id: int
    reason: str
    status: str
    created_at: datetime
    
    class Config:
        from_attributes = True

class AdminStats(BaseModel):
    top_contributors: list[dict]
    most_tagged_users: list[dict]
