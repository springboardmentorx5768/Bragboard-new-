import time
from fastapi.testclient import TestClient
from main import app
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database import Base, get_db
import os

# Use unique file for testing
db_file = f"test_edit_{int(time.time())}.db"
SQLALCHEMY_DATABASE_URL = f"sqlite:///./{db_file}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def test_edit_post_flow():
    Base.metadata.create_all(bind=engine)
    
    try:
        # 1. Register User A
        client.post("/api/register", json={
            "name": "User A",
            "email": "usera@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        
        # 2. Login User A
        login_res = client.post("/api/login", json={"email": "usera@example.com", "password": "password"})
        token_a = login_res.json()["access_token"]
        headers_a = {"Authorization": f"Bearer {token_a}"}
        
        # 3. Create Post by A
        create_res = client.post("/api/posts/", data={"title": "Original Title", "message": "Original Message"}, headers=headers_a)
        post_id = create_res.json()["id"]
        
        # 4. Edit Post (User A - Owner)
        edit_res = client.put(f"/api/posts/{post_id}", data={"title": "Updated Title", "message": "Updated Message"}, headers=headers_a)
        assert edit_res.status_code == 200, f"Edit failed: {edit_res.text}"
        assert edit_res.json()["post"]["title"] == "Updated Title"
        
        # 5. Verify Update Persisted
        get_res = client.get("/api/posts/", headers=headers_a)
        post = get_res.json()[0]
        assert post["title"] == "Updated Title"
        assert post["message"] == "Updated Message"
        
        # 6. Register User B
        client.post("/api/register", json={
            "name": "User B",
            "email": "userb@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        login_res_b = client.post("/api/login", json={"email": "userb@example.com", "password": "password"})
        token_b = login_res_b.json()["access_token"]
        headers_b = {"Authorization": f"Bearer {token_b}"}
        
        # 7. Edit Post (User B - Not Owner) - Should Fail
        fail_res = client.put(f"/api/posts/{post_id}", data={"title": "Hacked Title", "message": "Hacked"}, headers=headers_b)
        assert fail_res.status_code == 403, "User B should not edit User A's post"
        
        print("ALL EDIT TESTS PASSED")

    finally:
        engine.dispose()
        # Clean up
        if os.path.exists(db_file):
            try:
                os.remove(db_file)
            except:
                pass

if __name__ == "__main__":
    test_edit_post_flow()
