import time
from fastapi.testclient import TestClient
from main import app
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database import Base, get_db
import os

# Use unique file for testing to avoid file locking issues
db_file = f"test_posts_{int(time.time())}.db"
SQLALCHEMY_DATABASE_URL = f"sqlite:///./{db_file}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def test_delete_post_flow():
    Base.metadata.create_all(bind=engine)
    
    try:
        # 1. Register User A
        client.post("/api/register", json={
            "name": "User A",
            "email": "usera@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        
        # 2. Login User A
        login_res = client.post("/api/login", json={"email": "usera@example.com", "password": "password"})
        assert login_res.status_code == 200, f"Login A failed: {login_res.text}"
        token_a = login_res.json()["access_token"]
        headers_a = {"Authorization": f"Bearer {token_a}"}
        
        # 3. Create Post by A
        create_res = client.post("/api/posts/", data={"title": "Post A", "message": "Content A"}, headers=headers_a)
        assert create_res.status_code == 200, f"Create Post failed: {create_res.text}"
        post_id = create_res.json()["id"]
        
        # 4. Verify Post Exists
        get_res = client.get("/api/posts/", headers=headers_a)
        posts = get_res.json()
        assert len(posts) == 1
        assert posts[0]["id"] == post_id
        # Check sender_id field presence
        assert "sender_id" in posts[0]
        
        # 5. Register User B (same dept)
        client.post("/api/register", json={
            "name": "User B",
            "email": "userb@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        login_res_b = client.post("/api/login", json={"email": "userb@example.com", "password": "password"})
        token_b = login_res_b.json()["access_token"]
        headers_b = {"Authorization": f"Bearer {token_b}"}
        
        # 6. User B tries to delete User A's post (Should Fail)
        del_fail = client.delete(f"/api/posts/{post_id}", headers=headers_b)
        assert del_fail.status_code == 403, "User B should not be able to delete User A's post"
        
        # 7. User A deletes their post (Should Success)
        del_success = client.delete(f"/api/posts/{post_id}", headers=headers_a)
        assert del_success.status_code == 200, f"Delete failed: {del_success.text}"
        
        # 8. Verify Post Gone
        get_res_after = client.get("/api/posts/", headers=headers_a)
        assert len(get_res_after.json()) == 0, "Post should be gone"
        
        print("ALL POST TESTS PASSED")

    finally:
        # Dispose engine to close connections (good practice)
        engine.dispose()

if __name__ == "__main__":
    try:
        test_delete_post_flow()
    except Exception as e:
        print(f"TEST FAILED: {e}")
        exit(1)
