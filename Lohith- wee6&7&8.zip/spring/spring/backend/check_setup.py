
import sys
import os

# Add current directory to path so we can import main
sys.path.append(os.getcwd())

try:
    print("Attempting to import main...")
    from main import app
    print("Successfully imported main.")
    
    from database import engine
    print("Attempting to connect to database...")
    connection = engine.connect()
    print("Successfully connected to database!")
    connection.close()
    
    print("Backend check passed.")
except Exception as e:
    print(f"Backend check FAILED: {e}")
    import traceback
    traceback.print_exc()
