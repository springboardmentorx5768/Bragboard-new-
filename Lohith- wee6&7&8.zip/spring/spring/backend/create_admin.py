from sqlalchemy.orm import Session
from database import SessionLocal, engine
import models
import auth
import sys

def create_admin(email, password, name="Admin"):
    db = SessionLocal()
    try:
        # Check if user exists
        user = db.query(models.User).filter(models.User.email == email).first()
        
        if user:
            print(f"User with email {email} already exists.")
            if user.role != models.UserRole.admin:
                print("Promoting user to admin...")
                user.role = models.UserRole.admin
                db.commit()
                print("User promoted successfully.")
            else:
                print("User is already an admin.")
            return

        # Create new admin user
        print("Creating new admin user...")
        hashed_password = auth.Hash.make(password)
        new_admin = models.User(
            name=name,
            email=email,
            password=hashed_password,
            department="Administration",
            role=models.UserRole.admin
        )
        
        db.add(new_admin)
        db.commit()
        print(f"Admin user {email} created successfully.")
        
    except Exception as e:
        print(f"Error: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python create_admin.py <email> <password> [name]")
        print("Example: python create_admin.py admin@example.com admin123")
    else:
        email = sys.argv[1]
        password = sys.argv[2]
        name = sys.argv[3] if len(sys.argv) > 3 else "Admin"
        create_admin(email, password, name)
