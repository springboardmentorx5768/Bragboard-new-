import time
from fastapi.testclient import TestClient
from main import app
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database import Base, get_db
import os

# Use unique file for testing
db_file = f"test_react_{int(time.time())}.db"
SQLALCHEMY_DATABASE_URL = f"sqlite:///./{db_file}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def test_reaction_flow():
    Base.metadata.create_all(bind=engine)
    
    try:
        # 1. Register User A
        client.post("/api/register", json={
            "name": "User A",
            "email": "usera@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        login_res_a = client.post("/api/login", json={"email": "usera@example.com", "password": "password"})
        token_a = login_res_a.json()["access_token"]
        headers_a = {"Authorization": f"Bearer {token_a}"}
        
        # 2. Register User B
        client.post("/api/register", json={
            "name": "User B",
            "email": "userb@example.com",
            "password": "password",
            "department": "IT",
            "role": "employee"
        })
        login_res_b = client.post("/api/login", json={"email": "userb@example.com", "password": "password"})
        token_b = login_res_b.json()["access_token"]
        headers_b = {"Authorization": f"Bearer {token_b}"}
        
        # 3. Create Post by A
        create_res = client.post("/api/posts/", data={"title": "Test Post", "message": "Content"}, headers=headers_a)
        post_id = create_res.json()["id"]
        
        # 4. User A reacts -> Count 1
        react1 = client.post(f"/api/posts/{post_id}/react", headers=headers_a)
        assert react1.status_code == 200
        assert react1.json()["reaction_count"] == 1
        assert react1.json()["user_has_reacted"] == True
        
        # 5. User A reacts again -> Count 0 (Toggle Off)
        react2 = client.post(f"/api/posts/{post_id}/react", headers=headers_a)
        assert react2.status_code == 200
        assert react2.json()["reaction_count"] == 0
        assert react2.json()["user_has_reacted"] == False
        
        # 6. User B reacts -> Count 1
        react3 = client.post(f"/api/posts/{post_id}/react", headers=headers_b)
        assert react3.status_code == 200
        assert react3.json()["reaction_count"] == 1
        assert react3.json()["user_has_reacted"] == True
        
        # 7. Check Post Data (Global view)
        get_res = client.get("/api/posts/", headers=headers_a)
        post_data = get_res.json()[0]
        assert post_data["reaction_count"] == 1
        assert post_data["user_has_reacted"] == False # User A currently strictly hasn't liked it (B did)
        
        print("ALL REACTION TESTS PASSED")

    finally:
        engine.dispose()
        if os.path.exists(db_file):
            try:
                os.remove(db_file)
            except:
                pass

if __name__ == "__main__":
    test_reaction_flow()
