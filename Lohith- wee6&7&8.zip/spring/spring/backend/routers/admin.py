from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from database import get_db
import models, schemas
from dependencies import get_current_user

router = APIRouter(
    prefix="/admin",
    tags=["Admin"]
)

def get_current_admin(current_user: models.User = Depends(get_current_user)):
    if current_user.role != models.UserRole.admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    return current_user

@router.get("/stats", response_model=schemas.AdminStats)
def get_admin_stats(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_admin)):
    # Top Contributors (Most posts)
    top_contributors = (
        db.query(models.User.name, func.count(models.Post.id).label("count"))
        .join(models.Post, models.User.id == models.Post.sender_id)
        .group_by(models.User.id)
        .order_by(desc("count"))
        .limit(5)
        .all()
    )
    
    # Most Tagged Users (Most shoutout receipts)
    most_tagged = (
        db.query(models.User.name, func.count(models.ShoutoutRecipient.id).label("count"))
        .join(models.ShoutoutRecipient, models.User.id == models.ShoutoutRecipient.recipient_id)
        .group_by(models.User.id)
        .order_by(desc("count"))
        .limit(5)
        .all()
    )

    return {
        "top_contributors": [{"name": tc[0], "count": tc[1]} for tc in top_contributors],
        "most_tagged_users": [{"name": mt[0], "count": mt[1]} for mt in most_tagged]
    }

@router.get("/logs", response_model=list[schemas.AdminLogResponse])
def get_admin_logs(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_admin)):
    return db.query(models.AdminLog).order_by(models.AdminLog.timestamp.desc()).limit(50).all()

def log_admin_action(db: Session, admin_id: int, action: str, target_id: int, target_type: str):
    log = models.AdminLog(
        admin_id=admin_id,
        action=action,
        target_id=target_id,
        target_type=target_type
    )
    db.add(log)
    db.commit()

@router.delete("/posts/{post_id}")
def admin_delete_post(post_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_admin)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    db.delete(post)
    db.commit()
    
    log_admin_action(db, current_user.id, "DELETE_POST", post_id, "post")
    return {"message": "Post deleted successfully"}

@router.delete("/comments/{comment_id}")
def admin_delete_comment(comment_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_admin)):
    comment = db.query(models.Comment).filter(models.Comment.id == comment_id).first()
    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found")
    
    db.delete(comment)
    db.commit()
    
    log_admin_action(db, current_user.id, "DELETE_COMMENT", comment_id, "comment")
    return {"message": "Comment deleted successfully"}

@router.get("/reports", response_model=list[schemas.ReportResponse])
def get_reports(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_admin)):
    return db.query(models.Report).order_by(models.Report.created_at.desc()).all()

@router.put("/reports/{report_id}/resolve")
def resolve_report(report_id: int, status_update: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_admin)):
    report = db.query(models.Report).filter(models.Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
        
    report.status = status_update # e.g., "resolved", "dismissed"
    db.commit()
    
    log_admin_action(db, current_user.id, f"RESOLVE_REPORT_{status_update.upper()}", report_id, "report")
    return {"message": "Report updated"}

from fastapi.responses import StreamingResponse
import csv
import io

@router.get("/export/reports")
def export_reports_csv(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_admin)):
    reports = db.query(models.Report).order_by(models.Report.created_at.desc()).all()
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Date", "Reporter", "Reason", "Status", "Post ID"])
    
    for r in reports:
        writer.writerow([r.id, r.created_at, r.reporter.name, r.reason, r.status, r.post_id])
    
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=reports.csv"}
    )

@router.get("/export/stats")
def export_stats_csv(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_admin)):
    # Reusing the stats logic
    top_contributors = (
        db.query(models.User.name, func.count(models.Post.id).label("count"))
        .join(models.Post, models.User.id == models.Post.sender_id)
        .group_by(models.User.id)
        .order_by(desc("count"))
        .limit(20)
        .all()
    )
    
    most_tagged = (
        db.query(models.User.name, func.count(models.ShoutoutRecipient.id).label("count"))
        .join(models.ShoutoutRecipient, models.User.id == models.ShoutoutRecipient.recipient_id)
        .group_by(models.User.id)
        .order_by(desc("count"))
        .limit(20)
        .all()
    )
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    writer.writerow(["TOP CONTRIBUTORS"])
    writer.writerow(["Name", "Posts"])
    for tc in top_contributors:
        writer.writerow([tc[0], tc[1]])
        
    writer.writerow([])
    writer.writerow(["MOST APPRECIATED"])
    writer.writerow(["Name", "Shoutouts Received"])
    for mt in most_tagged:
        writer.writerow([mt[0], mt[1]])
        
    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=admin_stats.csv"}
    )
