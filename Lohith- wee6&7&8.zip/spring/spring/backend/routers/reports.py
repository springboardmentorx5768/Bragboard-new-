from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
import models, schemas
from dependencies import get_current_user

router = APIRouter(
    prefix="/reports",
    tags=["Reports"]
)

@router.post("/", response_model=schemas.ReportResponse)
def create_report(
    post_id: int,
    report: schemas.ReportCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")

    new_report = models.Report(
        reporter_id=current_user.id,
        post_id=post_id,
        reason=report.reason
    )
    db.add(new_report)
    db.commit()
    db.refresh(new_report)
    return new_report
