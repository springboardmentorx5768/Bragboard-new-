from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas
from dependencies import get_current_user
from services.post_service import PostService
from services.reaction_service import ReactionService
from services.comment_service import CommentService

router = APIRouter(prefix="/posts", tags=["Posts"])

import json

@router.post("/")
def create_post(
    title: str = Form(...),
    message: str = Form(...),
    recipient_ids: str = Form(None), # JSON string of IDs
    image: UploadFile = File(None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    parsed_recipient_ids = []
    if recipient_ids:
        try:
            parsed_recipient_ids = json.loads(recipient_ids)
        except:
            pass # Or raise error

    post = PostService.create_post(db, title, message, current_user.id, image, parsed_recipient_ids)
    return {"message": "Post created successfully", "id": post.id}

@router.get("/")
def get_posts(
    sender: str = None,
    department: str = None,
    date: str = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    posts = PostService.get_filtered_posts(
        db, 
        current_user.id, 
        current_user.department,
        sender_name=sender,
        target_department=department,
        date_str=date
    )
    
    # Enrich with reaction data
    results = []
    for p in posts:
        counts = ReactionService.get_reaction_counts(db, p.id)
        user_reactions = ReactionService.get_user_reactions(db, p.id, current_user.id)
        
        results.append({
            "id": p.id,
            "title": p.title,
            "message": p.message,
            "image_url": p.image_url,
            "created_at": p.created_at,
            "sender_id": p.sender_id,
            "sender_name": p.sender.name,
            "sender_department": p.sender.department,
            "reaction_counts": counts,
            "user_reactions": user_reactions,
            "recipients": [
                {"id": r.recipient.id, "name": r.recipient.name, "department": r.recipient.department} 
                for r in p.recipients
            ]
        })
    return results

@router.delete("/{post_id}")
def delete_post(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    if post.sender_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to delete this post")

    PostService.delete_post(db, post)
    return {"message": "Post deleted successfully"}

@router.put("/{post_id}")
def update_post(
    post_id: int,
    title: str = Form(None),
    message: str = Form(None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    if post.sender_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to edit this post")

    updated_post = PostService.update_post(db, post, title, message)
    return {
        "message": "Post updated successfully",
        "post": {
            "id": updated_post.id,
            "title": updated_post.title,
            "message": updated_post.message
        }
    }

# --- Reaction Endpoints ---

@router.post("/{post_id}/react")
def react_to_post(
    post_id: int,
    reaction: schemas.ReactionCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    # Department check: Removed to allow anyone to like the post (except owner)
    # if post.sender.department != current_user.department:
    #      raise HTTPException(status_code=403, detail="Cannot react to posts from other departments")

    # Restrict owner from reacting to their own post
    if post.sender_id == current_user.id:
        raise HTTPException(status_code=403, detail="You cannot react to your own post")

    result = ReactionService.toggle_reaction(db, post_id, current_user.id, reaction.reaction_type)
    
    # Return new count and state
    counts = ReactionService.get_reaction_counts(db, post_id)
    user_reactions = ReactionService.get_user_reactions(db, post_id, current_user.id)
    
    return {
        "message": "Reaction updated",
        "status": result["status"],
        "reaction_counts": counts,
        "user_reactions": user_reactions
    }

@router.get("/{post_id}/reactions")
def get_post_reactions(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    reactions = ReactionService.get_reactions_for_post(db, post_id)
    return reactions

# --- Comment Endpoints ---

@router.post("/{post_id}/comments", response_model=schemas.CommentResponse)
def add_comment(
    post_id: int,
    comment: schemas.CommentCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    created_comment = CommentService.create_comment(db, post_id, current_user.id, comment.content)
    
    # Construct response with user name
    return schemas.CommentResponse(
        id=created_comment.id,
        shoutout_id=created_comment.shoutout_id,
        user_id=created_comment.user_id,
        content=created_comment.content,
        created_at=created_comment.created_at,
        user_name=current_user.name
    )

@router.get("/{post_id}/comments", response_model=list[schemas.CommentResponse])
def get_comments(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    post = PostService.get_post(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
        
    comments = CommentService.get_comments_for_post(db, post_id)
    
    results = []
    for c in comments:
        results.append(schemas.CommentResponse(
            id=c.id,
            shoutout_id=c.shoutout_id,
            user_id=c.user_id,
            content=c.content,
            created_at=c.created_at,
            user_name=c.user.name
        ))
    return results
