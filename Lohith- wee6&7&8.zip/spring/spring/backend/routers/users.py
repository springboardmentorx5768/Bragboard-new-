from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
import models
import schemas
from dependencies import get_current_user
from services.user_service import UserService

router = APIRouter(prefix="/users", tags=["Users"])

@router.get("/", response_model=list[schemas.UserBasic])
def get_users(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    # Fetch all users for tagging (or filter if strictly needed, but broad tagging is standard)
    return UserService.get_all_users(db)

@router.get("/me", response_model=schemas.UserResponse)
def read_users_me(current_user: models.User = Depends(get_current_user)):
    return current_user

from sqlalchemy import func, desc
@router.get("/leaderboard")
def get_leaderboard(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # Logic similar to admin stats but intended for public view
    top_contributors = (
        db.query(models.User.name, func.count(models.Post.id).label("count"))
        .join(models.Post, models.User.id == models.Post.sender_id)
        .group_by(models.User.id)
        .order_by(desc("count"))
        .limit(10)
        .all()
    )
    
    most_tagged = (
        db.query(models.User.name, func.count(models.ShoutoutRecipient.id).label("count"))
        .join(models.ShoutoutRecipient, models.User.id == models.ShoutoutRecipient.recipient_id)
        .group_by(models.User.id)
        .order_by(desc("count"))
        .limit(10)
        .all()
    )

    return {
        "top_contributors": [{"name": tc[0], "count": tc[1]} for tc in top_contributors],
        "most_appreciated": [{"name": mt[0], "count": mt[1]} for mt in most_tagged]
    }
