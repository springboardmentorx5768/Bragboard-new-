import requests
import sys

BASE_URL = "http://localhost:8000/api"

def login(email, password):
    response = requests.post(f"{BASE_URL}/login", data={"username": email, "password": password})
    if response.status_code == 200:
        return response.json()["access_token"]
    print(f"Login failed: {response.text}")
    sys.exit(1)

def create_post(token):
    headers = {"Authorization": f"Bearer {token}"}
    data = {"title": "Test Post for Comments", "message": "This is a test post."}
    response = requests.post(f"{BASE_URL}/posts/", data=data, headers=headers)
    if response.status_code == 200:
        return response.json()["id"]
    print(f"Create post failed: {response.text}")
    sys.exit(1)

def add_comment(token, post_id, content):
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.post(f"{BASE_URL}/posts/{post_id}/comments", json={"content": content}, headers=headers)
    if response.status_code == 200:
        print("Comment added successfully.")
        return response.json()
    print(f"Add comment failed: {response.text}")
    sys.exit(1)

def get_comments(token, post_id):
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/posts/{post_id}/comments", headers=headers)
    if response.status_code == 200:
        print("Comments retrieved successfully.")
        return response.json()
    print(f"Get comments failed: {response.text}")
    sys.exit(1)

if __name__ == "__main__":
    # 1. Login
    # Assuming a user exists from previous setups, e.g., 'test@example.com' / 'password123'
    # If not, I might need to register one.
    # I'll try to register a new user to be safe.
    
    email = "comment_tester@example.com"
    password = "password123"
    
    requests.post(f"{BASE_URL}/register", json={"name": "Comment Tester", "email": email, "password": password})
    # Ignore error if already exists, try login
    
    token = login(email, password)
    print(f"Logged in as {email}")
    
    # 2. Create Post
    post_id = create_post(token)
    print(f"Created post {post_id}")
    
    # 3. Add Comment
    comment = add_comment(token, post_id, "This is a test comment!")
    print(f"Created comment: {comment}")
    
    # 4. Get Comments
    comments = get_comments(token, post_id)
    print(f"Retrieved {len(comments)} comments")
    
    found = any(c['content'] == "This is a test comment!" for c in comments)
    if found:
        print("Verification SUCCESS!")
    else:
        print("Verification FAILED: Comment not found in list.")
