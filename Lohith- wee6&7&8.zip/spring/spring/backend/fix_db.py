import sys
import os

sys.path.append(os.getcwd())

from database import engine
from sqlalchemy import text

def reset_reactions_table():
    with engine.connect() as connection:
        try:
            print("Dropping post_reactions table...")
            connection.execute(text("DROP TABLE IF EXISTS post_reactions CASCADE"))
            connection.commit()
            print("Table dropped successfully.")
        except Exception as e:
            print(f"Error dropping table: {e}")

if __name__ == "__main__":
    reset_reactions_table()
