
import requests

from datetime import datetime, date
# Configuration
BASE_URL = "http://127.0.0.1:8000"
USER_EMAIL = "test_filter_user@example.com"
USER_PASSWORD = "password123"
DEPT_A = "Engineering"
DEPT_B = "HR"

def get_auth_token(email, password):
    try:
        response = requests.post(f"{BASE_URL}/auth/token", data={"username": email, "password": password})
        if response.status_code == 200:
            return response.json()["access_token"]
    except:
        pass
    return None

def create_user_if_not_exists(name, email, password, department):
    # Try login first
    token = get_auth_token(email, password)
    if token:
        return token
    
    # Register
    requests.post(f"{BASE_URL}/auth/register", json={
        "name": name,
        "email": email,
        "password": password,
        "department": department
    })
    return get_auth_token(email, password)

def create_post(token, title, message):
    response = requests.post(f"{BASE_URL}/api/posts/", 
        headers={"Authorization": f"Bearer {token}"},
        data={"title": title, "message": message}
    )
    return response.json()

def test_filtering():
    # Setup users
    token_eng = create_user_if_not_exists("Eng User", "eng@test.com", "pass", DEPT_A)
    token_hr = create_user_if_not_exists("HR User", "hr@test.com", "pass", DEPT_B)
    
    # Create posts
    create_post(token_eng, "Eng Post 1", "Engineering Update") # Today
    create_post(token_hr, "HR Post 1", "HR Update") # Today

    print("\n--- Verifying Default View (Engineering User) ---")
    # Should see Eng Post, NOT HR Post
    res = requests.get(f"{BASE_URL}/api/posts/", headers={"Authorization": f"Bearer {token_eng}"})
    print(f"Response Status: {res.status_code}")
    posts = res.json()
    print(f"Raw Response: {posts}")
    try:
        print(f"Default Posts Count: {len(posts)}")
        titles = [p['title'] for p in posts]
        print(f"Titles: {titles}")
        if "Eng Post 1" in titles and "HR Post 1" not in titles:
            print("PASS: Default scoping works")
        else:
            print("FAIL: Default scoping incorrect")
    except Exception as e:
        print(f"Error parsing response: {e}")
        print(f"Posts type: {type(posts)}")

    print("\n--- Verifying Department Filter (View HR from Eng) ---")
    res = requests.get(f"{BASE_URL}/api/posts/?department={DEPT_B}", headers={"Authorization": f"Bearer {token_eng}"})
    print(f"Response Status: {res.status_code}")
    posts = res.json()
    print(f"Raw Response: {posts}")
    try:
        titles = [p['title'] for p in posts]
        print(f"Filtered Dept Posts: {titles}")
        if "HR Post 1" in titles:
            print("PASS: Department filtering works")
        else:
            print("FAIL: Department filtering failed")
    except Exception as e:
        print(f"Error parsing response: {e}")

    print("\n--- Verifying Sender Filter ---")
    res = requests.get(f"{BASE_URL}/api/posts/?sender=HR", headers={"Authorization": f"Bearer {token_eng}"})
    print(f"Response Status: {res.status_code}")
    posts = res.json()
    print(f"Raw Response: {posts}")
    try:
        titles = [p['title'] for p in posts]
        print(f"Filtered Sender Posts: {titles}")
        if any("HR" in t for t in titles) or "HR Post 1" in titles:
             print("PASS: Sender filtering works")
    except Exception as e:
        print(f"Error parsing response: {e}")

    print("\n--- Verifying Date Filter ---")
    today = date.today().isoformat()
    res = requests.get(f"{BASE_URL}/api/posts/?date={today}", headers={"Authorization": f"Bearer {token_eng}"})
    print(f"Response Status: {res.status_code}")
    posts = res.json()
    print(f"Raw Response: {posts}")
    try:
        print(f"Posts from today ({today}): {len(posts)}")
        if len(posts) > 0:
            print("PASS: Date filtering works (found posts created today)")
        else:
            print("FAIL: Date filtering failed")
    except Exception as e:
        print(f"Error parsing response: {e}")

if __name__ == "__main__":
    test_filtering()
