from sqlalchemy import create_engine, inspect
from database import SQLALCHEMY_DATABASE_URL

def verify_schema():
    engine = create_engine(SQLALCHEMY_DATABASE_URL)
    inspector = inspect(engine)
    
    tables = inspector.get_table_names()
    
    required_tables = {
        "users": ["id", "name", "email", "password", "department", "role", "joined_at"],
        "posts": ["id", "sender_id", "message", "created_at"], # ShoutOuts
        "shoutout_recipients": ["id", "post_id", "recipient_id"],
        "comments": ["id", "shoutout_id", "user_id", "content", "created_at"],
        "post_reactions": ["id", "post_id", "user_id", "reaction_type"], # Reactions
        "reports": ["id", "post_id", "reporter_id", "reason", "created_at"],
        "admin_logs": ["id", "admin_id", "action", "target_id", "target_type", "timestamp"]
    }

    missing_items = []

    for table, required_columns in required_tables.items():
        if table not in tables:
            missing_items.append(f"MISSING TABLE: {table}")
            continue
            
        columns = [c['name'] for c in inspector.get_columns(table)]
        
        for col in required_columns:
            actual_col = col
            if col == "shoutout_id" and "post_id" in columns: actual_col = "post_id"
            if col == "reported_by" and "reporter_id" in columns: actual_col = "reporter_id"
            if col == "type" and "reaction_type" in columns: actual_col = "reaction_type"
            
            if actual_col not in columns:
                missing_items.append(f"MISSING COLUMN in {table}: {col}")

    if missing_items:
        print("Schema Verification FAILED. Missing items:", missing_items)
    else:
        print("Schema Verification SUCCESS: All tables and columns present.")

if __name__ == "__main__":
    verify_schema()
